/*
* igWebDataGridColumnFixing.js
* Version 19.2.20192.8
* Copyright(c) 2001-2019 Infragistics, Inc. All Rights Reserved.
*/




$IG.IColumnFixingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IColumnFixingBehavior">
	///Interface that identifies the column fixing behavior.
	///</summary>
};

$IG.IColumnFixingBehavior.prototype =
{
	get_headerRegions: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IColumnFixingBehavior.headerRegions">
		/// Returns a two dimentional array.  The first dimention contains the regions that 
		/// the WebDataGrid header is devided into and the second dimention contains all the TH
		/// elements in that region.
		/// </summary>
	}
};

$IG.IColumnFixingBehavior.registerInterface("Infragistics.Web.UI.IColumnFixingBehavior");




$IG.ColumnFixing = function (obj, objProps, control, parentCollection)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnFixing">
	///Column fixing behavior for the WebDataGrid.
	///</summary>	
	$IG.ColumnFixing.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._grid = this._owner;

	this._get_cellElementByIndexHandler = Function.createDelegate(this, this._get_cellElementByIndex);
	this._grid._gridUtil._registerEventListener(this._grid, "GetCellElementByIndex", this._get_cellElementByIndexHandler);

	
	
	this._getGridCellFromElementHandler = this._grid._gridUtil._getGridCellFromElement;
	this._grid._gridUtil._getGridCellFromElement = Function.createDelegate(this, this._getGridCellFromElement);

	this._getCellIndexFromElemHandler = this._grid._gridUtil.getCellIndexFromElem;
	this._grid._gridUtil.getCellIndexFromElem = Function.createDelegate(this, this.getCellIndexFromElem);

	this._findRowIndexByCellElemHandler = this._grid._gridUtil.findRowIndexByCellElem;
	this._grid._gridUtil.findRowIndexByCellElem = Function.createDelegate(this, this.findRowIndexByCellElem);

	this._scrollCellIntoViewIEHandler = this._grid._gridUtil.scrollCellIntoViewIE;
	this._grid._gridUtil.scrollCellIntoViewIE = Function.createDelegate(this, this.scrollCellIntoViewIE);



	if (!$util.IsIE && !$util.IsSafari)	
		this.__createScrollStyleSheet();			

	this._initScrollDivs();

	
	this._headerRegions = [];

	
	this._fixedColumns = [];
	this.__initializeFixedColumns();

	this.__initializeColumnWidthCssClasses();
	this._fixButtons = control._elements["fixBtn"];
	if (this._fixButtons && !this._fixButtons.length)
	{
		var fixBtn = this._fixButtons;
		this._fixButtons = [];
		this._fixButtons[0] = fixBtn;
	}
	this._fixButtonsObjs = [];

	this._autoAdjustCells = this._get_clientOnlyValue("cfach");
	this._fixedCss = this._get_clientOnlyValue("fcss");
	this._leftFixedCount = this._get_clientOnlyValue("leftC");
	this._rightFixedCount = this._get_clientOnlyValue("rightC");
	this._unfixedCount = this._grid.get_columns().get_length() - this._leftFixedCount - this._rightFixedCount;


	this._leftFixedDataColCount = this._get_clientOnlyValue("leftDC");
	this._rightFixedDataColCount = this._get_clientOnlyValue("rightDC");
	if (!this._grid._hasHeaderLayout)
	{
		this._leftFixedDataColCount = this._leftFixedCount;
		this._rightFixedDataColCount = this._rightFixedCount;
	}
	this._unfixedDataColCount = this._grid.get_columns().get_length() - this._leftFixedDataColCount - this._rightFixedDataColCount;

	this._leftSeparator = control._elements["lftSeparator"];
	this._rightSeparator = control._elements["rhtSeparator"];

	var stopperStylClassName = this._get_clientOnlyValue("fcscc");
	if (stopperStylClassName)
		this._stopperStyleCss = this._getStyleSheet(stopperStylClassName);
	className = this._get_clientOnlyValue("fcthscc");
	if (className)
		this._captionStopperStyleCss = this._getStyleSheet(className);

	this._checkScrollDivsInitialized();

	this._onImgMouseOverHandler = Function.createDelegate(this, this._onImgMouseOver);
	this._onImgMouseOutHandler = Function.createDelegate(this, this._onImgMouseOut);
	this._onImgMouseDownHandler = Function.createDelegate(this, this._onImgMouseDown);
	this._onImgMouseClickHandler = Function.createDelegate(this, this._onImgMouseClick);
	for (var i = 0; this._fixButtons && this._fixButtons.length && i < this._fixButtons.length; i++)
	{
		$addHandler(this._fixButtons[i], 'mouseover', this._onImgMouseOverHandler);
		$addHandler(this._fixButtons[i], 'mouseout', this._onImgMouseOutHandler);
		$addHandler(this._fixButtons[i], 'mousedown', this._onImgMouseDownHandler);
		$addHandler(this._fixButtons[i], 'click', this._onImgMouseClickHandler);
	}

	this._onShowHorizontalScrollBarHandler = Function.createDelegate(this, this._onShowHorizontalScrollBar);
	this._grid._gridUtil._registerEventListener(this._grid, "ShowHorizontalScrollBar", this._onShowHorizontalScrollBarHandler);

	this._onHorizontalScrollBarWidthInitHandler = Function.createDelegate(this, this._onHorizontalScrollBarWidthInit);
	this._grid._gridUtil._registerEventListener(this._grid, "HorizontalScrollBarWidthInit", this._onHorizontalScrollBarWidthInitHandler);

	this._onGridScrollLeftChangeHandler = Function.createDelegate(this, this._onGridScrolled);
	this._grid._gridUtil._registerEventListener(this._grid, "ScrollLeftChange", this._onGridScrollLeftChangeHandler);

	this._onGridTouchScrollingLeftHandler = Function.createDelegate(this, this._onGridTouchScrollingLeft);
	this._grid._gridUtil._registerEventListener(this._grid, "TouchScrollingLeft", this._onGridTouchScrollingLeftHandler);


	this._onGridCScrollLeftChangeHandler = Function.createDelegate(this, this._onGridCScrollLeft);
	this._grid._gridUtil._registerEventListener(this._grid, "CScrollLeftChange", this._onGridCScrollLeftChangeHandler);

	this._onAlignFooterHandler = Function.createDelegate(this, this._onAlignFooter);
	this._grid._gridUtil._registerEventListener(this._grid, "AlignFooter", this._onAlignFooterHandler);

	this._onAlignStatCaptionHandler = Function.createDelegate(this, this._onAlignStatCaption);
	this._grid._gridUtil._registerEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);

	this._onInitializedLayoutHandler = Function.createDelegate(this, this._initializedLayout);
	this._grid._gridUtil._registerEventListener(this._grid, "InitializedLayout", this._onInitializedLayoutHandler);

	this._onResizeHandler = Function.createDelegate(this, this._resizeSeparators);
	this._grid._gridUtil._registerEventListener(this._grid, "Resize", this._onResizeHandler);

	this._onAsyncRenderingHandler = Function.createDelegate(this, this._onAsyncRendering);
	this._grid._gridUtil._registerEventListener(this._grid, "AsyncRendering", this._onAsyncRenderingHandler);

	this._onSetColumnWidthHandler = Function.createDelegate(this, this._onSetColumnWidth);
	this._grid._gridUtil._registerEventListener(this._grid, "SetColumnWidth", this._onSetColumnWidthHandler);

	this._onCellContentChangedHandler = Function.createDelegate(this, this._onCellContentChanged);
	this._grid._gridUtil._registerEventListener(this._grid, "CellContentChanged", this._onCellContentChangedHandler);

	this._onFilterCellEnteringEditHandler = Function.createDelegate(this, this._onFilterCellEnteringEdit);
	this._grid._gridUtil._registerEventListener(this._grid, "FilterCellEnteringEdit", this._onFilterCellEnteringEditHandler);

	this._onHiddenColumnHander = Function.createDelegate(this, this._onHiddenColumn);
	this._grid._gridUtil._registerEventListener(this._grid, "HideColumn", this._onHiddenColumnHander);

	if (this._grid.get_enableClientRendering())
	{
		this._onDataBoundHandler = Function.createDelegate(this, this._onDataBound);
		this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
	}


	this._addStyleToRowHandler = this._grid._gridUtil._addStyleToRow;
	this._grid._gridUtil._addStyleToRow = Function.createDelegate(this, this._addStyleToRow);

	this._removeStyleFromRowHandler = this._grid._gridUtil._removeStyleFromRow;
	this._grid._gridUtil._removeStyleFromRow = Function.createDelegate(this, this._removeStyleFromRow);

	this._onCalculatingAdjacentHandler = Function.createDelegate(this, this._onCalculatingAdjacent);
	this._grid._gridUtil._registerEventListener(this._grid, "CalculatingAdjacent", this._onCalculatingAdjacentHandler);

	this._onCreatingSizeRowHandler = Function.createDelegate(this, this._onCreatingSizeRow);
	this._grid._gridUtil._registerEventListener(this._grid, "CreateSizingRow", this._onCreatingSizeRowHandler);

	
	this._onCellScrollToViewHandler = Function.createDelegate(this, this._onCellScrollToView);
	this._grid._gridUtil._registerEventListener(this._grid, "CellScrollToView", this._onCellScrollToViewHandler);

	if ($util.IsFireFox)
	{
		
		this._onStylesHaveBeenAppendedHandler = Function.createDelegate(this, this._onStylesHaveBeenAppended);
		this._grid._gridUtil._registerEventListener(this._grid, "StylesHaveBeenAppended", this._onStylesHaveBeenAppendedHandler);
	}
}

$IG.ColumnFixing.prototype =
{
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the Column Fixing behavior removes all the event handlers that it
		/// had attached.
		/// </summary>
		if (!this._grid)
			return;

		this._grid._gridUtil._unregisterEventListener(this._grid, "GetCellElementByIndex", this._get_cellElementByIndexHandler);
		delete this._get_cellElementByIndexHandler;

		
		this._grid._gridUtil._getGridCellFromElement = this._getGridCellFromElementHandler;
		delete this._getGridCellFromElementHandler;

		this._grid._gridUtil.getCellIndexFromElem = this._getCellIndexFromElemHandler;
		delete this._getCellIndexFromElemHandler;

		this._grid._gridUtil.findRowIndexByCellElem = this._findRowIndexByCellElemHandler;
		delete this._findRowIndexByCellElemHandler;

		this._grid._gridUtil.scrollCellIntoViewIE = this._scrollCellIntoViewIEHandler;
		delete this._scrollCellIntoViewIEHandler;

		this._grid._gridUtil._addStyleToRow = this._addStyleToRowHandler;
		delete this._addStyleToRowHandler;

		this._grid._gridUtil._removeStyleFromRow = this._removeStyleFromRowHandler;
		delete this._removeStyleFromRowHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "ShowHorizontalScrollBar", this._onShowHorizontalScrollBarHandler);
		delete this._onShowHorizontalScrollBarHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "HorizontalScrollBarWidthInit", this._onHorizontalScrollBarWidthInitHandler);
		delete this._onHorizontalScrollBarWidthInitHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollLeftChange", this._onGridScrollLeftChangeHandler);
		delete this._onGridScrollLeftChangeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "TouchScrollingLeft", this._onGridTouchScrollingLeftHandler);
		delete this._onGridTouchScrollingLeftHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "CScrollLeftChange", this._onGridCScrollLeftChangeHandler);
		delete this._onGridCScrollLeftChangeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AlignFooter", this._onAlignFooterHandler);
		delete this._onAlignFooterHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);
		delete this._onAlignStatCaptionHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "InitializedLayout", this._onInitializedLayoutHandler);
		delete this._onInitializedLayoutHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "Resize", this._onResizeHandler);
		delete this._onResizeHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AsyncRendering", this._onAsyncRenderingHandler);
		delete this._onAsyncRenderingHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "SetColumnWidth", this._onSetColumnWidthHandler);
		delete this._onSetColumnWidthHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "CellContentChanged", this._onCellContentChangedHandler);
		delete this._onCellContentChangedHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "FilterCellEnteringEdit", this._onFilterCellEnteringEditHandler);
		delete this._onFilterCellEnteringEditHandler;

		this._grid._gridUtil._unregisterEventListener(this._grid, "HideColumn", this._onHiddenColumnHander);
		delete this._onHiddenColumnHander;

		this._grid._gridUtil._unregisterEventListener(this._grid, "CreateSizingRow", this._onCreatingSizeRowHandler);
		delete this._onCreatingSizeRowHandler;

		
		this._grid._gridUtil._unregisterEventListener(this._grid, "CellScrollToView", this._onCellScrollToViewHandler);
		delete this._onCellScrollToViewHandler;

		if ($util.IsFireFox && this._onStylesHaveBeenAppendedHandler)
		{
			
			this._grid._gridUtil._unregisterEventListener(this._grid, "StylesHaveBeenAppended", this._onStylesHaveBeenAppendedHandler);
			delete this._onStylesHaveBeenAppendedHandler;
		}

		this._grid._gridUtil._unregisterEventListener(this._grid, "CalculatingAdjacent", this._onCalculatingAdjacentHandler);
		delete this._onCalculatingAdjacentHandler;

		if (this._onDataBoundHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
			delete this._onDataBoundHandler;
		}

		if (this._activation)
		{
			this._grid._gridUtil._unregisterEventListener(this._activation, "AddingActiveRowCssClass", this._addingActiveRowCssClassHandler);
			delete this._addingActiveRowCssClassHandler;

			this._grid._gridUtil._unregisterEventListener(this._activation, "RemovingActiveRowCssClass", this._removingActiveRowCssClassHandler);
			delete this._removingActiveRowCssClassHandler;

			this._grid._gridUtil._unregisterEventListener(this._grid, "KeyDown", this._onKeyDownHandler);
			delete this._onKeyDownHandler;
			delete this._activation;
		}
		if (this._editingCore && this._editingCore._batchUpdating)
		{
			if (this._onRemovingEmptyTemplateHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "RemovedEmptyTemplate", this._onRemovingEmptyTemplateHandler);
				delete this._onRemovingEmptyTemplateHandler;
			}
			if (this._onAddingCellsToBatchAddedRowHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "NewBatchRowAddingCells", this._onAddingCellsToBatchAddedRowHandler);
				delete this._onAddingCellsToBatchAddedRowHandler;
			}
			if (this._onBatchCellAddCssHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "BatchCellAddCss", this._onBatchCellAddCssHandler);
				delete this._onBatchCellAddCssHandler;
			}
			if (this._onRowAddedBatchHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "RowAddedBatch", this._onRowAddedBatchHandler);
				delete this._onRowAddedBatchHandler;
			}
			if (this._onBatchUpdateUndoneHandler)
			{
				this._grid._gridUtil._unregisterEventListener(this._grid, "BatchUpdateUndone", this._onBatchUpdateUndoneHandler);
				delete this._onBatchUpdateUndoneHandler;
			}
		}
		if (this._columnResizing)
			delete this._columnResizing;
		if (this._virtualScrolling)
			delete this._virtualScrolling;
		delete this._cellEditing;
		delete this._rowAdding;
		delete this._editingCore;
		delete this._summaryRow;
		delete this._filtering;

		for (var i = 0; this._fixButtons && this._fixButtons.length && i < this._fixButtons.length; i++)
		{
			$removeHandler(this._fixButtons[i], 'mouseover', this._onImgMouseOverHandler);
			$removeHandler(this._fixButtons[i], 'mouseout', this._onImgMouseOutHandler);
			$removeHandler(this._fixButtons[i], 'mousedown', this._onImgMouseDownHandler);
			$removeHandler(this._fixButtons[i], 'click', this._onImgMouseClickHandler);
		}
		delete this._onImgMouseOverHandler;
		delete this._onImgMouseOutHandler;
		delete this._onImgMouseDownHandler;
		delete this._onImgMouseClickHandler;

		for (var i = 0; i < this._fixedColumns.length; i++)
			this._fixedColumns[i].dispose();

		delete this._enteringEditModeHandler;
		delete this._fixedColumns;
		delete this._fixButtons;
		delete this._fixButtonsObjs;
		delete this._headerRegions;

		this._columnSettings.dispose();
		delete this._columnSettings;

		delete this._scrollDivs;
		delete this._scrollStyleSheet;

		delete this._autoAdjustCells;
		delete this._fixedCss;
		delete this._leftFixedCount;
		delete this._rightFixedCount;
		delete this._unfixedCount;

		delete this._leftSeparator;
		delete this._rightSeparator;
		
		delete this._leftSeparatorFooter;
		delete this._rightSeparatorFooter;

		delete this._stopperStyleCss;
		delete this._captionStopperStyleCss;
		delete this._grid;

		$IG.ColumnFixing.callBaseMethod(this, "dispose");


	},

	
	get_headerRegions: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.headerRegions">
		/// Returns a two dimentional array.  The first dimention contains the regions that 
		/// the WebDataGrid header is devided into and the second dimention contains all the TH
		/// elements in that region.
		/// </summary>
		return this._headerRegions;
	},
	


	

	
	get_columnSettings: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSettings">
		/// Gets the column fixing settings collection
		/// </summary>
		/// <returns type="ObjectCollection">column fixing settings collection </returns>
		return this._columnSettings;
	},
	

	get_columnSetting: function (index)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSetting">
		/// Gets the column fixing setting object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <returns type="ColumnFixingSettings">The column fixing setting at the specified index</returns>
		if (index >= 0 && index < this._columnSettings._items.length)
			return this._columnSettings._items[index];
		else
			return null;
	},

	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.columnSettingFromKey">
		/// Gets the column fixing setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column fixing setting is tied to.
		///</param>
		/// <returns type="ColumnFixingSettings">The column fixing setting tied to the specified column key</returns>

		for (var i = 0; i < this._columnSettings._items.length; i++)
		{
			if (this._columnSettings._items[i].get_columnKey() === columnKey)
				return this._columnSettings._items[i];
		}

		return null;
	},
	


	
	get_fixedColumns: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixedColumns">
		/// Returns an array with the columns that are currently fixed.
		/// </summary>
		/// <returns type="Array">An array of FixedColumnInfo objects. </returns>
		return this._fixedColumns;
	},

	getFixedColumnFromKey: function (key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.getFixedColumnFromKey">
		/// Returns the fixed column for the specified column key.
		/// </summary>
		///<param name="key" type="String"  optional="false" mayBeNull="false">
		/// The column key of the fixed column.
		///</param>
		/// <returns type="$IG.FixedColumnInfo">The fixed column object for the given key.  
		/// Null will be returned if the column is not found. </returns>

		for (var i = 0; i < this._fixedColumns.length; i++)
		{
			if (this._fixedColumns[i].get_column().get_key() == key)
				return this._fixedColumns[i];
		}
		return null;
	},

	containsFixedColumnByKey: function (key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.containsFixedColumnByKey">
		/// Returns the true/false based on whether the column associated with the given key is currently fixed..
		/// </summary>
		/// <param name="key" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column.
		/// </param>
		/// <returns type="boolean">True is the column is currently fixed, false otherwise. </returns>

		for (var i = 0; i < this._fixedColumns.length; i++)
		{
			if (this._fixedColumns[i].get_column().get_key() == key)
				return true;
		}
		return false;
	},

	createFixedColumnObj: function (column, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.createFixedColumnObj">
		///	Creates a $IG.FixedColumnInfo object for the given column.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column for which to create a $IG.FixedColumnInfo object.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, $IG.FixedColumnInfo will be created with the given fix location,
		/// if not there than the $IG.FixedColumnInfo object will be created to the fix location specified in settings or behavior default
		/// </param>

		if (!column)
			return null;
		fixLocation = this._determineFixLocation(column.get_key(), fixLocation);

		return new $IG.FixedColumnInfo(column, fixLocation);
	},
	

	
	get_autoAdjustCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.autoAdjustCells">
		/// Gets the setting for whether the cell height of the unfixed columns needs to be kept
		/// in sync with the cell height of the fixed columns.		
		/// </summary>
		/// <returns type="boolean">True - adjust cell height. False - do not adjust cell height. </returns>

		return this._autoAdjustCells;
	},

	get_fixLocation: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixLocation">
		/// Gets the direction to which all columns are fixed to unless otherwise specified in the 
		/// ColumnSetting object for the column
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the columns will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the columns will be fixed to the right edge of the grid
		/// </returns>

		return this._get_value($IG.GridColumnFixingProps.FixLocation);
	},
	set_fixLocation: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixLocation">
		/// Sets direction to which all columns are fixed to unless otherwise specified in the 
		/// ColumnSetting object for the column
		/// </summary>
		/// <param name="value" type="$IG.FixLocation"  optional="false" mayBeNull="false">
		/// $IG.FixLocation.Left - the columns will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the columns will be fixed to the right edge of the grid
		/// </param>

		if (value == $IG.FixLocation.Left || value == $IG.FixLocation.Right)
			this._set_value($IG.GridColumnFixingProps.FixLocation, value);
	},
	get_fixButtonAlignment: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.fixButtonAlignment">
		/// Indicate whether the fix button/pin is located to the left or to the right of the header caption.
		/// </summary>
		/// <returns type="$IG.HeaderButtonAlignment">Location of the button.</returns>

		return this._get_clientOnlyValue("cfbtna");
	},

	get_leftFixedCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.leftFixedCount">
		/// The number of columns that are currently fixed to the left
		/// edge of the grid.
		/// </summary>
		/// <returns type="Integer">Count.</returns>

		return this._leftFixedCount;
	},

	get_rightFixedCount: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixing.rightFixedCount">
		/// The number of columns that are currently fixed to the right
		/// edge of the grid.
		/// </summary>
		/// <returns type="Integer">Count.</returns>

		return this._rightFixedCount;
	},

	

	

	fixColumn: function (column, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumn">
		/// Fixes the given column, if the column settings allow.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column to be fixed.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (column && column.get_key() && (this._grid.get_columns().get_columnFromKey(column.get_key()) || (this._grid._hasHeaderLayout && this._grid._gridUtil._get_HeaderLayoutColumnFromKey(column.get_key()))) && (!this._grid._hasHeaderLayout || this._grid._gridUtil._isTopLevelHeaderLayoutColumn(column.get_key())))
			this._fixColumn(column.get_key(), fixLocation);

	},

	fixColumnByKey: function (columnKey, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnByKey">
		/// Fixes the column associated with the given column key, if the column settings allow.
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column that is to be fixed.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (this._grid.get_columns().get_columnFromKey(columnKey) || (this._grid._hasHeaderLayout && this._grid._gridUtil._get_HeaderLayoutColumnFromKey(columnKey)))
			this._fixColumn(columnKey, fixLocation);
	},

	fixColumnByIndex: function (columnIndex, fixLocation)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnByIndex">
		/// Fixes the column associated with the given index, if the column settings allow.
		/// </summary>
		/// <param name="columnIndex" type="Integer"  optional="false" mayBeNull="false">
		/// The column index of the column in the columns collection that is to be fixed if multi-header columns are not used.
		/// If multi-header columns are present this needs to be the index in the headerColumnsLayout.
		/// </param>
		/// <param name="fixLocation" type="$IG.FixLocation"  optional="true" mayBeNull="true">
		/// If this parameter is present, the column will be fixed to the given edge,
		/// if not there than the column will be fixed to the direction specified in settings or behavior default
		/// </param>

		if (columnIndex > -1 && columnIndex < (this._grid._hasHeaderLayout ? this._grid.get_headerColumnsLayout().length : this._grid.get_columns().get_length()))
		{
			var key = (this._grid._hasHeaderLayout ? this._grid.get_headerColumnsLayout()[columnIndex] : this._grid.get_columns().get_column(columnIndex).get_key());
			this._fixColumn(key, fixLocation);
		}
	},

	fixColumnRange: function (columnKeys)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnRange">
		/// Fixes the columns associated with the given column keys, if the column settings allow.
		/// </summary>
		/// <param name="columnKeys" type="Array"  optional="false" mayBeNull="false">
		/// An array of Strings, which are the column keys associated to the columns that will be fixed.
		/// </param>

		
		if (this.getEditingOn())
			return;
		if (columnKeys && columnKeys.length)
		{
			var colInfo = [];
			for (var i = 0; i < columnKeys.length; i++)
			{

				if ((this._grid.get_columns().get_columnFromKey(columnKeys[i]) || (this._grid._hasHeaderLayout && this._grid._gridUtil._get_HeaderLayoutColumnFromKey(columnKeys[i]))) && (!this._grid._hasHeaderLayout || this._grid._gridUtil._isTopLevelHeaderLayoutColumn(columnKeys[i])))
					colInfo[colInfo.length] = this.__createTransportableFixedColumnObj(columnKeys[i], this._determineFixLocation(columnKeys[i], null));
			}

			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	fixColumnObjRange: function (fixedColumns)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.fixColumnObjRange">
		/// Fixes the given columns, if the column settings allow.
		/// </summary>
		/// <param name="fixedColumns" type="Array"  optional="false" mayBeNull="false">
		/// An array of $IG.FixedColumnInfo objects (these should be created with the createFixedColumnObj method of Column Fixing behavior).
		/// </param>

		
		if (this.getEditingOn())
			return;
		if (fixedColumns && fixedColumns.length)
		{
			var colInfo = [];
			for (var i = 0; i < fixedColumns.length; i++)
			{
				if (fixedColumns[i] && fixedColumns[i].get_column() && fixedColumns[i].get_column().get_key())
				{
					var columnKey = fixedColumns[i].get_column().get_key();
					if ((this._grid.get_columns().get_columnFromKey(columnKey) || (this._grid._hasHeaderLayout && this._grid._gridUtil._get_HeaderLayoutColumnFromKey(columnKey))) && (!this._grid._hasHeaderLayout || this._grid._gridUtil._isTopLevelHeaderLayoutColumn(columnKey)))
						colInfo[colInfo.length] = this.__createTransportableFixedColumnObj(columnKey, this._determineFixLocation(columnKey, fixedColumns[i].get_fixLocation()));
				}
			}

			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	unfixColumn: function (column)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumn">
		/// Unfixes the given column, if the column is currently fixed.
		/// </summary>
		/// <param name="column" type="$IG.GridColumn"  optional="false" mayBeNull="false">
		/// The column to be unfixed.
		/// </param>

		if (column && column.get_key())
			this._unfixColumn(column.get_key());
	},

	unfixColumnByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnByKey">
		/// Unfixes the column associated with the given column key, if the column is currently fixed.
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key associated with the column that is to be unfixed.
		/// </param>

		if (columnKey)
			this._unfixColumn(columnKey);

	},
	unfixColumnByIndex: function (columnIndex)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnByIndex">
		/// Unfixes the column associated with the given index, if the column is currently fixed.
		/// </summary>
		/// <param name="columnIndex" type="Integer"  optional="false" mayBeNull="false">
		/// The column index of the column in the columns collection that is to be unfixed if multi-header columns are not used.
		/// If multi-header columns are present this needs to be the index in the headerColumnsLayout.
		/// </param>

		if (columnIndex > -1 && columnIndex < (this._grid._hasHeaderLayout ? this._grid.get_headerColumnsLayout().length : this._grid.get_columns().get_length()))
		{
			var key = (this._grid._hasHeaderLayout ? this._grid.get_headerColumnsLayout()[columnIndex] : this._grid.get_columns().get_column(columnIndex).get_key());
			this._unfixColumn(key);
		}
	},

	unfixColumnRange: function (columnKeys)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.unfixColumnRange">
		/// Unfixes the columns associated with the given column keys, if the columns are currently fixed.
		/// </summary>
		/// <param name="columnKeys" type="Array"  optional="false" mayBeNull="false">
		/// An array of Strings, which are the column keys associated to the columns that will be unfixed.
		/// </param>

		if (columnKeys)
		{
			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("UnfixColumnManual", this.get_name(), this._grid, columnKeys, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	adjustUnfixedCellHeight: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnFixing.adjustUnfixedCellHeight">
		/// Adjusts the cell height of the unfixed columns so they are kept
		/// in sync with the cell height of the fixed columns.
		/// </summary>

		if (this.__unfixedCellHeightTimer)
			return;
		this.__unfixedCellHeightTimer = window.setTimeout(Function.createDelegate(this, this.__onUnfixedHeightTimerExpire), 100);

		tableRows = (this._grid._elements.rows) ? this._grid._elements.rows.childNodes : null;
		if (tableRows)
		{
			var index = (tableRows.length && tableRows.length > 0) ? this.__findColsSpanIndex(tableRows[0]) : null;
			if (index != null)
			{
				var operaResizeNeeded = false;
				for (var i = 0; i < tableRows.length; i++)
				{
					var tableRow = tableRows[i];
					if (tableRow.tagName != "TR")
						continue;
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
					{
						operaResizeNeeded = true;
						if ($util.IsIEStandards || ($util.IsOpera && !this.get_autoAdjustCells()))
							divElement.firstChild.style.height = "";
						divElement.style.height = height + "px";
						if ($util.IsIEStandards || ($util.IsOpera && !this.get_autoAdjustCells()))
							setTimeout($util.createDelegate(this, this._adjustIE8Opera, [divElement.firstChild]), 0);
					}
				}
				if ($util.IsOpera && !this.get_autoAdjustCells() && operaResizeNeeded)
					setTimeout($util.createDelegate(this, this._forceGridResize), 0);
			}
		}
	},
	

	
	_initScrollDivs: function ()
	{
		this._scrollDivs = this._grid._elements["unfixedDiv"];
		
		if (this._scrollDivs == null || this._scrollDivs == undefined)
			this._scrollDivs = [];
		else if (this._scrollDivs.length === undefined || this._scrollDivs.tagName)
			this._scrollDivs = [this._scrollDivs];

		var cellDivs = this._grid._elements.dataTbl.getElementsByTagName('div');
		if (this._grid.get_enableClientRendering())
		{
			var numOfunfixedDivs = 0;
			for (var i = 0; i < cellDivs.length; i++)
			{
				var cellDiv = cellDivs[i];
				$util._initAttr(cellDiv);
				if (cellDiv.getAttribute("mkr") == "unfixedDiv")
				{
					cellDiv.id = cellDiv.id + numOfunfixedDivs.toString();
					this._scrollDivs[this._scrollDivs.length] = cellDiv;
					
					this._ensureScrollHandler(cellDiv);
					
					if (numOfunfixedDivs % 2 != 0)
						$(cellDiv.firstChild.firstChild.firstChild).addClass(this._grid._get_clientOnlyValue("rac"));
					numOfunfixedDivs++;
				}
			}
		}
		
		for (var i = 0; i < cellDivs.length; i++)
		{
			// can not use commented, because under Firefox "unfixedDiv" are never initialized
			//if (cellDivs[i].getAttribute("mkr") == "unfixedDiv")
			if ($util._isXAttrContains(cellDivs[i], "mkr:unfixedDiv"))
				this._ensureScrollHandler(cellDivs[i]);
		}
	},
	_checkScrollDivsInitialized: function ()
	{
		

		if (!this._scrollDivs && this._stopperStyleCss)
		{
			var row = this._grid._rows.get_row(0);
			if (row)
			{
				var rowElem = this._grid.__getResizeRowElement(row);
				var i = 0;
				var stopperStylClassName = this._get_clientOnlyValue("fcscc");
				var stopperClassName = this._getClassNameOnly(stopperStylClassName);
				while (!this._scrollDivs && rowElem && i < rowElem.childNodes.length)
				{
					var cell = rowElem.childNodes[i];
					if (cell.className.indexOf(stopperClassName) != -1 && cell.firstChild && cell.firstChild.tagName == "DIV" &&
					$util._isXAttrContains(cell.firstChild, "mkr:unfixedDiv"))
					{
						this._scrollDivs = cell.firstChild;
					}
					i++;
				}
			}
		}
	},
	_onDataBound: function (args)
	{
		this._initScrollDivs();
		this._checkScrollDivsInitialized();
		if (this._grid._hScrBar)
			this._onGridScrolled();
	},
	_onHiddenColumn: function (evnt)
	{
		if ($util.IsOpera)
			setTimeout($util.createDelegate(this, this._forceGridResize), 0);
	},
	_adjustIE8Opera: function (table)
	{
		table.style.height = "100%";
	},
	_onSetColumnWidth: function (eventArgs)
	{
		eventArgs.cancel = true;
		var column = eventArgs.column;
		var columnWidth = eventArgs.width;

		
		if (column._headerElement)
			column._headerElement.style.width = columnWidth;
		if (column._footerElement)
			column._footerElement.style.width = columnWidth;
		if (this._grid.get_rows().get_length() > 0)
		{
			var rowZero = this._grid.get_rows().get_row(0);
			
			var sizingRowElem = this._grid.__getResizeRowElement(rowZero);
			var sizingRow = new $IG.GridRow(null, sizingRowElem, [], this._owner, null);

			var cellElmenet = sizingRow.get_cellByColumn(column).get_element();
			cellElmenet.style.width = columnWidth;
			if (this.__isUnfixedTD(cellElmenet))
			{
				var tdStyle = this._getStyleSheet(column._columnWidthCssClass);
				tdStyle.width = columnWidth;
			}
		}
		
		if ($util.IsIE6)
			setTimeout($util.createDelegate(this._owner, this._owner._onResize, [{ "clientHeight": this._grid._element.clientHeight }, false]), 2);
		else
			this._owner._onResize({ "clientHeight": this._grid._element.clientHeight }, false);

	},
	_onAsyncRendering: function (eventArgs)
	{
		var element = eventArgs.gridElement;
		var newElement = eventArgs.newElement.firstChild;
		var tableElement = eventArgs.tableElement;

		
		if (this._leftSeparator)
		{
			element.removeChild(this._leftSeparator);
			if ($util.IsIE)
				this._leftSeparator.removeNode();
			delete this._leftSeparator;
		}

		if (this._rightSeparator)
		{
			element.removeChild(this._rightSeparator);
			if ($util.IsIE)
				this._rightSeparator.removeNode();
			delete this._rightSeparator;
		}


		while (newElement && !(newElement.tagName == "TABLE" && $util._isXAttrContains(newElement, "outerTbl")))
		{
			var nextNewElement = newElement.nextSibling;
			if ($util._isXAttrContains(newElement, "lftSeparator") || $util._isXAttrContains(newElement, "rhtSeparator"))
			{
				if (tableElement)
					element.insertBefore(newElement, tableElement);
				else
					element.appendChild(newElement);
			}
			newElement = nextNewElement;
		}
	},
	_fixColumn: function (columnKey, fixLocation)
	{
		
		if (this.getEditingOn())
			return;
		var columnSetting = this.get_columnSettingFromKey(columnKey);

		if (!columnSetting || (columnSetting && columnSetting.get_enabled()))
		{
			fixLocation = this._determineFixLocation(columnKey, fixLocation);

			if (this._doesColumnNeedFixing(columnKey, fixLocation))
			{
				var colInfo = this.__createTransportableFixedColumnObj(columnKey, fixLocation);
				var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
				this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumnManual", this.get_name(), this._grid, colInfo, null));
				this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},

	_unfixColumn: function (columnKey)
	{
		
		if (this.getEditingOn())
			return;
		if (this._doesColumnNeedUnfixing(columnKey))
		{
			var eventArgs = new $IG.FixUnfixColumnEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("UnfixColumnManual", this.get_name(), this._grid, columnKey, null));
			this._owner._raiseClientEventEnd(eventArgs);
		}
	},

	_doesColumnNeedFixing: function (columnKey, fixLocation)
	{
		var fixedCol = this.getFixedColumnFromKey(columnKey);
		if (!fixedCol || fixedCol.get_fixLocation() != fixLocation)
			return true;
		else
			return false;
	},

	_doesColumnNeedUnfixing: function (columnKey)
	{
		if (this.getFixedColumnFromKey(columnKey))
			return true;
		else
			return false;
	},

	_get_fixButtonObject: function (column, elem)
	{
		var key = column.get_key();
		if (this._fixButtonsObjs[key] == null)
		{
			if (this.getFixedColumnFromKey(key))
				this._fixButtonsObjs[key] = new $IG.ImageObject("fixBtn", elem, this._objectManager.get_objectProps(1), this);
			else
				this._fixButtonsObjs[key] = new $IG.ImageObject("fixBtn", elem, this._objectManager.get_objectProps(0), this);

			var altTxt = this._fixButtonsObjs[key]._get_clientOnlyValue("altTxt");
			

			altTxt = (altTxt ? altTxt : "");
			var btnElement = this._fixButtonsObjs[key].get_element();
			if (btnElement && column.get_headerElement())
			{
				var formatedAltTxt = String.format(altTxt, column.get_headerText());
				btnElement.alt = formatedAltTxt;
				btnElement.title = formatedAltTxt;
			}
		}
		return this._fixButtonsObjs[key];
	},

	_onImgMouseOver: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var column = null;
		if (evnt.target && evnt.target.parentNode)
		{
			if (this._grid._hasHeaderLayout)
			{
				if (evnt.target.parentNode.getAttribute("grpFld"))
					column = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(evnt.target.parentNode.getAttribute("key"));
				else
					column = this._grid.get_columns().get_columnFromKey(evnt.target.parentNode.getAttribute("key"));
			}
			else
				column = this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode);
		}
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Hover);
		}
	},

	_onImgMouseOut: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var column = null;
		if (evnt.target && evnt.target.parentNode)
		{
			if (this._grid._hasHeaderLayout)
			{
				if (evnt.target.parentNode.getAttribute("grpFld"))
					column = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(evnt.target.parentNode.getAttribute("key"));
				else
					column = this._grid.get_columns().get_columnFromKey(evnt.target.parentNode.getAttribute("key"));
			}
			else
				column = this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode);
		}
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Normal);
		}
	},

	_onImgMouseDown: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var column = null;
		if (evnt.target && evnt.target.parentNode)
		{
			if (this._grid._hasHeaderLayout)
			{
				if (evnt.target.parentNode.getAttribute("grpFld"))
					column = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(evnt.target.parentNode.getAttribute("key"));
				else
					column = this._grid.get_columns().get_columnFromKey(evnt.target.parentNode.getAttribute("key"));
			}
			else
				column = this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode);
		}
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Pressed);
		}
	},

	_onImgMouseClick: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var column = null;
		if (evnt.target && evnt.target.parentNode)
		{
			if (this._grid._hasHeaderLayout)
			{
				if (evnt.target.parentNode.getAttribute("grpFld"))
					column = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(evnt.target.parentNode.getAttribute("key"));
				else
					column = this._grid.get_columns().get_columnFromKey(evnt.target.parentNode.getAttribute("key"));
			}
			else
				column = this._grid._gridUtil._getColumnFromHeader(evnt.target.parentNode);
		}
		if (column)
		{
			var btn = this._get_fixButtonObject(column, evnt.target);
			if (btn)
				btn.setState($IG.ImageState.Normal);
			this.__changeFixState(column);
		}
	},

	__changeFixState: function (column, byKeyboard)
	{
		if (column)
		{
			var fixedColumn = this.getFixedColumnFromKey(column.get_key());
			var fixed = (fixedColumn) ? true : false;
			fixedColumn = (fixedColumn) ? fixedColumn : this.createFixedColumnObj(column);

			fixedColumn = new $IG.ClientFixedColumnInfo(fixedColumn.get_column(), fixedColumn.get_fixLocation());

			var eventArgs = new $IG.FixingEventArgs(this, fixedColumn, fixed);
			this._owner._raiseSenderClientEventStart(this, this._clientEvents["FixedStateChanging"], eventArgs);
			if (!eventArgs.get_cancel())
			{
				var fixedColumnInfo = this.__createTransportableFixedColumnObj(fixedColumn.get_column().get_key(), fixedColumn.get_fixLocation());

				var noPost = (eventArgs._props[1] == 2);
				this._grid._actionList.add_transaction(new $IG.ColumnFixingAction("FixColumn", this.get_name(), this._grid, fixedColumnInfo, (byKeyboard ? true : null)));
				if (!noPost)
					this._owner._postAction(1);
				else
					this._owner._raiseClientEventEnd(eventArgs);
			}
		}
	},

	_onKeyDown: function (event)
	{
		
		if (this.getEditingOn())
			return;
		if (event.ctrlKey && event.shiftKey && event.keyCode == 70)
		{
			if (this._cellEditing && this._cellEditing.get_cellInEditMode())
				return false;
			var cell = this._activation.get_activeCell();
			if (cell)
			{
				var column = cell.get_column();
				if (this._grid._hasHeaderLayout)
				{
					if (!this._grid._gridUtil._isTopLevelHeaderLayoutColumn(column.get_key()))
					{
						var childCol = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(column.get_key());
						column = null;
						while (column == null && childCol != null)
						{
							childCol = childCol._get_parent();
							if (childCol._get_parent() == this._grid)
								column = childCol;
						}
					}
				}
				this.__changeFixState(column, true);
			}
			return true;
		}
	},

	_determineFixLocation: function (columnKey, fixLocation)
	{
		var columnSetting = this.get_columnSettingFromKey(columnKey);
		if (fixLocation != $IG.FixLocation.Left && fixLocation != $IG.FixLocation.Right)
			fixLocation = (!columnSetting) ? this.get_fixLocation() : columnSetting.get_fixLocation();

		return fixLocation;
	},

	_onGridCScrollLeft: function (evntArgs)
	{
		evntArgs.containerScrollLeft = this._grid.get_scrollLeft();
	},
	_onGridScrolled: function (evnt)
	{		
	    this._grid._ignoreCScroll = true;
		var scroll = (this._grid._hScrBar.offsetHeight > 0) ? this._grid._hScrBar.scrollLeft : this._grid.get_scrollLeft();

		if ($util.IsIE || $util.IsSafari)
		{
			

			if (this._scrollDivs && !this._scrollDivs.length)
				this._scrollDivs.scrollLeft = scroll;

			for (var i = 0; this._scrollDivs && i < this._scrollDivs.length; i++)
				this._scrollDivs[i].scrollLeft = scroll;
		}
		else
		{
			this._scrollStyleSheet.left = (-scroll) + "px";
		}

		
		if (this._grid._cellInEditMode)
		{
			if (this._cellEditing && this._cellEditing.get_cellInEditMode())
				this._cellEditing._forceExitEditMode();
			else if (this._rowAdding && this._rowAdding.get_cellInEditMode())
				this._rowAdding._forceExitEditMode();
			else if (this._filtering && this._filtering.get_cellInEditMode())
				this._filtering._forceExitEditMode();
		}
		this._grid.set_scrollLeft(scroll);
		
		this._grid._gridUtil._fireEvent(this._grid, "ScrollLeftChanged");

	    
	    // D.A. April 2nd, 2015 Bug #184674 Increasing timeout, because sometimes in Firefox this timeout is executed before div.onScroll is fired (in _ensureScrollHandler function)
		if ($util.IsFireFox) {
		    var me = this;
		    setTimeout(function () {
		        delete me._grid._ignoreCScroll;
		    }, 100);
		}
		else
		    delete this._grid._ignoreCScroll;
		
		
		return true;
	},

	_onGridTouchScrollingLeft: function (evnt)
	{
		if ($util.IsIE || $util.IsSafari)
		{
			if (this._scrollDivs && !this._scrollDivs.length)
				this._scrollDivs.scrollLeft += evnt.deltaScrollLeft;

			for (var i = 0; this._scrollDivs && i < this._scrollDivs.length; i++)
				this._scrollDivs[i].scrollLeft += evnt.deltaScrollLeft;
		}
		else
		{
			var pxIndex = this._scrollStyleSheet.left.indexOf("px");
			var currentScroll = -parseInt(this._scrollStyleSheet.left.substring(0, pxIndex));
			var scroll = currentScroll + evnt.deltaScrollLeft;

			this._scrollStyleSheet.left = (-scroll) + "px";
		}

		
		return true;
	},

	_onScrolledCellIntoView: function (args)
	{
		var cell = args.cell;
		var elem = cell.get_element();
		args.cancel = true;
		
		if ($util.IsIE || $util.IsOpera || $util.IsSafari)
		{
			this._grid._gridUtil.scrollCellIntoViewIE(cell);
		}
		else
		{
			


			if ($util.IsFireFox && this._grid._notifyBehaviorTData)
				this._grid._notifyBehaviorTData._onTick();

			if (this.__isUnfixedTD(elem))
			{
				var pxIndex = this._scrollStyleSheet.left.indexOf("px");
				var originalScroll = -parseInt(this._scrollStyleSheet.left.substring(0, pxIndex));
				var currentStyleScroll = originalScroll;
				var div = elem.parentNode.parentNode.parentNode.parentNode;

				if (originalScroll != div.scrollLeft)
				{
					currentStyleScroll = 0;
					this._scrollStyleSheet.left = "0px";
					div.scrollLeft = originalScroll;

				}

				elem.focus();
				var currentDivScroll = div.scrollLeft;
				div.scrollLeft = 0;

				if (currentStyleScroll != currentDivScroll)
				{
					this._grid._hScrBar.scrollLeft = currentDivScroll;
					this._onGridScrolled();
				}
				
				else if (currentStyleScroll == currentDivScroll && currentStyleScroll != originalScroll)
					this._grid._hScrBar.scrollLeft = currentDivScroll;

			}
			else
			{
				
				if (elem)
					elem.focus();
			}

		}
	},

	_onHorizontalScrollBarWidthInit: function (scrollBar)
	{
	    var scrLeft, maxScrLeft, scrollDiv = null;
		if (this._grid._rows.get_length() < 1)
			scrollDiv = this.__getFirstScrollDiv();
		else
		{
			var row = this._grid.__getResizeRowElement(this._grid._rows.get_row(0));
			index = this.__findColsSpanIndex(row);
			if (index != null && index > -1 && index < row.childNodes.length)
				scrollDiv = row.childNodes[index].firstChild;
		}
		if (scrollDiv)
		{
			
			scrollBar.firstChild.style.width = scrollBar.clientWidth + (scrollDiv.firstChild.clientWidth - (scrollDiv.clientWidth == 0 ? scrollDiv.offsetWidth : scrollDiv.clientWidth)) + "px";
		    // N.R 11th Sept 2019 - fix bug 265390 - when rtl is set to true need to change scroll left
			scrLeft = this._grid.get_scrollLeft();
			if (this._grid._rtl && scrLeft == 0 && $util.IsChrome && !$util.IsEdge) {
			    maxScrLeft = this._grid._hScrBar.scrollWidth - this._grid._hScrBar.clientWidth;
			    scrLeft = Math.abs(scrLeft - maxScrLeft);
			}

			scrollBar.scrollLeft = scrLeft;
			var result = this._onGridScrolled();
		}

		return true;
	},

	_onShowHorizontalScrollBar: function (event)
	{
		var scrollDiv = null;
		if (this._grid._rows.get_length() < 1)
			scrollDiv = this.__getFirstScrollDiv();
		else
		{
			var row = this._grid.__getResizeRowElement(this._grid._rows.get_row(0));
			index = this.__findColsSpanIndex(row);
			if (index != null && index > -1 && index < row.childNodes.length)
				scrollDiv = row.childNodes[index].firstChild;
		}

		if (scrollDiv)
		{
			event.scrollBar.style.display = ((event.scrollContainer.offsetWidth + (scrollDiv.firstChild.clientWidth - scrollDiv.clientWidth)) > event.container.offsetWidth ? "" : "none");
			return true;
		}
		return false;
	},

	_initializedLayout: function ()
	{
		if (!this._grid._header && !this._grid._footer)
			this.__createSpaceForSeparators();
		this._resizeSeparators();

		var fixedByKeyboard = this._get_clientOnlyValue("fByKey");
		if (this._activation && fixedByKeyboard && this._activation.get_activeCell())
			this._activation.__focusCell(this._activation.get_activeCell());
	},

	_adjustUnfixedCaptionsHeight: function ()
	{
		
		this._adjustUnfixedCaptionsHeightHelper();
		var headerContent = this._grid._elements.headerContent;
		var headerRows = (headerContent && headerContent.firstChild) ? headerContent.firstChild.childNodes : null;

		var footerContent = this._grid._elements.footerContent;
		var footerRows = (footerContent && footerContent.firstChild) ? footerContent.firstChild.childNodes : null;

		var index = null;
		if (headerRows && headerRows.length && headerRows.length > 0)
		{
			index = this.__findColsSpanIndex(headerRows[0]);
			if (index != null)
			{
				for (var i = 0; i < headerRows.length; i++)
				{
					var tableRow = headerRows[i];
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
						divElement.style.height = height + "px";
				}
			}
			if (this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
			{
				var fixedLeftCaps = this._grid._elements["fxdCapThLeft"];
				if (fixedLeftCaps)
				{
					if (!fixedLeftCaps.length)
					{
						var tmp = fixedLeftCaps;
						fixedLeftCaps = [];
						fixedLeftCaps[0] = tmp;
					}
					for (var j = 0; j < fixedLeftCaps.length; j++)
					{
						if (j == 0 && this._grid.get_rows().get_length() == 0)
						{
							
							fixedLeftCaps[j].style.width = "1px";
							fixedLeftCaps[j].style.width = fixedLeftCaps[j].firstChild.offsetWidth + "px";
						}
						var height = fixedLeftCaps[j].offsetHeight;
						if (height != fixedLeftCaps[j].firstChild.clientHeight)
							fixedLeftCaps[j].firstChild.style.height = height + "px";
					}
				}

				var fixedRightCaps = this._grid._elements["fxdCapThRight"];
				if (fixedRightCaps)
				{
					if (!fixedRightCaps.length)
					{
						var tmp = fixedRightCaps;
						fixedRightCaps = [];
						fixedRightCaps[0] = tmp;
					}
					for (var j = 0; j < fixedRightCaps.length; j++)
					{
						if (j == 0 && this._grid.get_rows().get_length() == 0)
							fixedRightCaps[j].style.width = fixedRightCaps[j].firstChild.offsetWidth + "px";
						var height = fixedRightCaps[j].offsetHeight;
						if (height != fixedRightCaps[j].firstChild.clientHeight)
							fixedRightCaps[j].firstChild.style.height = height + "px";
					}
				}
			}
		}
		if (footerRows && footerRows.length && footerRows.length > 0)
		{
			if (index == null || this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
				index = this.__findColsSpanIndex(footerRows[0]);

			if (index != null)
			{
				for (var i = 0; i < footerRows.length; i++)
				{
					var tableRow = footerRows[i];

					if (this._summaryRow && tableRow.getAttribute("mkr") == "capSumRow")
						continue;
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					var height = tableRow.offsetHeight;
					if (height != divElement.clientHeight)
						divElement.style.height = height + "px";
				}
			}
		}
	},
	
	_adjustUnfixedCaptionsHeightHelper: function ()
	{
		var headerContent = this._grid._elements.headerContent;
		var headerRows = (headerContent && headerContent.firstChild) ? headerContent.firstChild.childNodes : null;

		var footerContent = this._grid._elements.footerContent;
		var footerRows = (footerContent && footerContent.firstChild) ? footerContent.firstChild.childNodes : null;

		var index = null;
		if (headerRows && headerRows.length && headerRows.length > 0)
		{
			index = this.__findColsSpanIndex(headerRows[0]);
			if (index != null)
			{
				for (var i = 0; i < headerRows.length; i++)
				{
					var tableRow = headerRows[i];
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					if (divElement.style.height != "")
						divElement.style.height = "";
				}
			}
			if (this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
			{
				var fixedLeftCaps = this._grid._elements["fxdCapThLeft"];
				if (fixedLeftCaps)
				{
					if (!fixedLeftCaps.length)
					{
						var tmp = fixedLeftCaps;
						fixedLeftCaps = [];
						fixedLeftCaps[0] = tmp;
					}
					for (var j = 0; j < fixedLeftCaps.length; j++)
					{

						if (fixedLeftCaps[j].firstChild.style.height != "")
							fixedLeftCaps[j].firstChild.style.height = "";
					}
				}

				var fixedRightCaps = this._grid._elements["fxdCapThRight"];
				if (fixedRightCaps)
				{
					if (!fixedRightCaps.length)
					{
						var tmp = fixedRightCaps;
						fixedRightCaps = [];
						fixedRightCaps[0] = tmp;
					}
					for (var j = 0; j < fixedRightCaps.length; j++)
					{
						if (fixedRightCaps[j].firstChild.style.height != "")
							fixedRightCaps[j].firstChild.style.height = "";
					}
				}
			}
		}
		if (footerRows && footerRows.length && footerRows.length > 0)
		{
			if (index == null || this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
				index = this.__findColsSpanIndex(footerRows[0]);

			if (index != null)
			{
				for (var i = 0; i < footerRows.length; i++)
				{
					var tableRow = footerRows[i];

					if (this._summaryRow && tableRow.getAttribute("mkr") == "capSumRow")
						continue;
					var cell = tableRow.childNodes[index];
					var divElement = cell.firstChild;
					if (divElement.style.height != "")
						divElement.style.height = "";
				}
			}
		}
	},
	_resizeSeparators: function ()
	{
		var scrollDiv = this.__getFirstScrollDiv();
		if (scrollDiv)
		{
			var contentTbl = this._grid._elements["contentTbl"];
			var gridMainDiv = this._grid.get_element();
			var leftEdge = gridMainDiv.offsetLeft;
			var rightEdge = gridMainDiv.offsetLeft + gridMainDiv.clientWidth;
			rightEdge -= this._grid._vScrBar ? this._grid._determineScrollbarWidth() : 0;

			var emptyRowTemplate = this._get_clientOnlyValue("hasEmptyRT") && this._grid.get_rows().get_length() == 0;
			if (this._leftSeparator)
			{
				var height;
				if (emptyRowTemplate)
				{
					height = this._grid._headingArea.offsetHeight;
					
					if (!this._leftSeparatorFooter && this._grid._footer)
					{
						this._leftSeparatorFooter = this._leftSeparator.cloneNode(true);
						
						$util._setXAttr(this._leftSeparatorFooter, $util._getXAttr(this._leftSeparatorFooter) + "Footer");
						//this._leftSeparatorFooter.id = this._leftSeparatorFooter.id + "Footer";
						this._leftSeparator.parentNode.insertBefore(this._leftSeparatorFooter, this._leftSeparator);
						this._leftSeparatorFooter.setAttribute("mkr", "lftSeparatorFooter");
					}
				}
				else
					height = contentTbl.clientHeight;

				var marginLeft = scrollDiv.parentNode.offsetLeft;

				//if (marginLeft < leftEdge || marginLeft > rightEdge)
				
				if (marginLeft < 0 || marginLeft > rightEdge - leftEdge)
				{
					this._leftSeparator.style.height = "0px";
					this._leftSeparator.style.marginLeft = "0px";

					
					if (this._leftSeparatorFooter)
					{
						this._leftSeparatorFooter.style.height = "0px";
						this._leftSeparatorFooter.style.marginLeft = "0px";
					}
				}
				else
				{
					this._leftSeparator.style.height = height + "px";
					this._leftSeparator.style.marginTop = contentTbl.parentNode.offsetTop + "px";
					this._leftSeparator.style.marginLeft = marginLeft + "px";

					
					if (this._leftSeparatorFooter)
					{
						this._leftSeparatorFooter.style.height = this._grid._footingArea.offsetHeight + "px";
						this._leftSeparatorFooter.style.marginTop = this._grid._footingArea.offsetTop + "px";
						this._leftSeparatorFooter.style.marginLeft = marginLeft + "px";
					}
				}

			}
			if (this._rightSeparator)
			{

				var height;
				if (emptyRowTemplate)
				{
					height = this._grid._headingArea.offsetHeight;

					
					if (!this._rightSeparatorFooter && this._grid._footer)
					{
						this._rightSeparatorFooter = this._rightSeparator.cloneNode(true);
						
						//this._rightSeparatorFooter.id = this._rightSeparatorFooter.id + "Footer";
						$util._setXAttr(this._rightSeparatorFooter, $util._getXAttr(this._rightSeparatorFooter) + "Footer");
						this._rightSeparator.parentNode.insertBefore(this._rightSeparatorFooter, this._rightSeparator);
						this._rightSeparatorFooter.setAttribute("mkr", "rhtSeparatorFooter");
					}
				}
				else
					height = contentTbl.clientHeight;

				var cell = scrollDiv.parentNode;
				var marginLeft = cell.offsetLeft + cell.clientWidth - this._rightSeparator.clientWidth;
				//if (marginLeft < leftEdge || marginLeft > rightEdge)
				
				if (marginLeft < 0 || marginLeft > rightEdge - leftEdge)
				{
					this._rightSeparator.style.height = "0px";
					this._rightSeparator.style.marginLeft = "0px";

					
					if (this._rightSeparatorFooter)
					{
						this._rightSeparatorFooter.style.height = "0px";
						this._rightSeparatorFooter.style.marginLeft = "0px";
					}

				}
				else
				{
					this._rightSeparator.style.height = height + "px";
					this._rightSeparator.style.marginLeft = marginLeft + "px";
					this._rightSeparator.style.marginTop = contentTbl.parentNode.offsetTop + "px";

					
					if (this._rightSeparatorFooter)
					{
						this._rightSeparatorFooter.style.height = this._grid._footingArea.offsetHeight + "px";
						this._rightSeparatorFooter.style.marginTop = this._grid._footingArea.offsetTop + "px";
						this._rightSeparatorFooter.style.marginLeft = marginLeft + "px";
					}
				}
			}
		}
	},

	_onAlignFooter: function ()
	{
		var headerContent = this._grid._elements["headerContent"];
		var footerContent = this._grid._elements["footerContent"];
		var headerRows = $util.getRows(headerContent);
		var headerRow = (headerRows && headerRows.length) ? headerRows[0] : null;
		var footerRows = $util.getRows(footerContent);

		var existingTableWidth;
		if (this._grid._elements.dataTbl)
		{
			var dataTblStyle = this._grid._elements.dataTbl.style;
			existingTableWidth = dataTblStyle.width;

			if (headerContent)
			{
				if (headerContent.style.tableLayout != "fixed")
					headerContent.style.tableLayout = "fixed";
				if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
					headerContent.style.width = dataTblStyle.width;
			}
			if (footerContent)
			{
				if (footerContent.style.tableLayout != "fixed")
					footerContent.style.tableLayout = "fixed";
				if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
					footerContent.style.width = dataTblStyle.width;
			}
		}

		if (headerRow)
		{
			for (var i = 1; i < headerRows.length; i++)
			{
				var captions = headerRows[i].childNodes;

				this.__alignPixeledStatCaption(headerRow.childNodes, captions, existingTableWidth, true);
				this.__alignNonePixeledStatCaption(headerRow.childNodes, captions);
			}

			for (var i = 0; footerRows && i < footerRows.length; i++)
			{
			    var captions = footerRows[i].childNodes;

			    this.__alignPixeledStatCaption(headerRow.childNodes, captions, existingTableWidth, true);
			    this.__alignNonePixeledStatCaption(headerRow.childNodes, captions, (this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters ? true : false));
			}
		}
		else if (footerRows && footerRows.length > 1)
		{
			var footerRow = footerRows[footerRows.length - 1];
			for (var i = 0; i < footerRows.length - 1; i++)
			{
				var captions = footerRows[i].childNodes;

				this.__alignPixeledStatCaption(footerRow.childNodes, captions, existingTableWidth, true);
				this.__alignNonePixeledStatCaption(footerRow.childNodes, captions);
			}
		}
		return true;

	},

	_onAlignStatCaption: function (eventArgs)
	{
		var captionProperty = eventArgs.captionProperty;
		var capElem = this._grid._elements[captionProperty];
		if (capElem.style.tableLayout != "fixed")
			capElem.style.tableLayout = "fixed";

		var existingTableWidth;
		if (this._grid._elements.dataTbl)
		{
			var dataTblStyle = this._grid._elements.dataTbl.style;
			existingTableWidth = dataTblStyle.width;
			if (existingTableWidth && (existingTableWidth + "").indexOf("px") != -1)
			{
				capElem.style.width = dataTblStyle.width;
			}
		}

		this.__createSpaceForSeparators();

		var row = this._grid._rows.get_row(0);
		if (row)
		{
			var rowElem = this._grid.__getResizeRowElement(row);

			var rows = $util.getRows(capElem);
			for (var i = 0; rows && i < rows.length; i++)
			{
				var captions = rows[i].childNodes;

				this.__alignPixeledStatCaption(rowElem.childNodes, captions, existingTableWidth);
				this.__alignNonePixeledStatCaption(rowElem.childNodes, captions);
			}

			if (this.get_autoAdjustCells())
				this.adjustUnfixedCellHeight();

		}
		this._adjustUnfixedCaptionsHeight();
		this._resizeSeparators();
		return true;

	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.ColumnFixingSettings, null, columnKey);

	},

	_createObjects: function (objectManager)
	{
		this._objectManager = objectManager;
		this._objectManager.__createdObjectCount = 0;

		$IG.ColumnFixing.callBaseMethod(this, "_createObjects", [objectManager]);
	},

	_onCellContentChanged: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		if (!this.__isUnfixedTD(cellElement))
		{
			var row = evntArgs.cell.get_row().get_element();
			var index = (row) ? this.__findColsSpanIndex(row) : null;
			if (index)
			{
				var cell = row.childNodes[index];
				var divElement = cell.firstChild;
				if (divElement.style.height != "")
					divElement.style.height = "";

				divElement.firstChild.style.height = "";
				setTimeout($util.createDelegate(this, this._setDivElementHeight, [divElement, row]), 0);
			}
		}
	},

	_setDivElementHeight: function (divElement, row)
	{
		var height = row.offsetHeight;
		if (height != divElement.clientHeight)
			divElement.style.height = height + "px";
		divElement.firstChild.style.height = "100%";

	},

	_enteringEditMode: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		var parentCell = this.__getColSpanTDFromUnfixedCell(cellElement);
		if (parentCell)
		{
			var leftBounds = parentCell.offsetLeft;
			var rightBounds = null;
			if (this._rightSeparator)
			{
				var pxIndex = this._rightSeparator.style.marginLeft.indexOf("px");
				if (pxIndex > -1)
					rightBounds = parseInt(this._rightSeparator.style.marginLeft.substring(0, pxIndex));
			}
			if (rightBounds == null)
			{
				rightBounds = leftBounds + parentCell.clientWidth;
				var pd = $util.getStyleValue(null, "paddingRight", parentCell);
				pd = parseInt(pd);
				if (!isNaN(pd))
					rightBounds -= pd;
			}

			var paddingLeft = $util.getStyleValue(null, "paddingLeft", parentCell);
			paddingLeft = parseInt(paddingLeft);

			
			if (!isNaN(paddingLeft))
				leftBounds += paddingLeft;

			var width = cellElement.offsetWidth;

			var left = cellElement.offsetLeft + parentCell.offsetLeft;

		    // N.R January 27, 2016 bug 203651: The editor which becomes visible when a cell is in edit mode is not aligned with the cell when column fixing is enabled.
			if (!isNaN(paddingLeft) && ($util.IsChrome || ($util.IsFireFox && (!this._grid._hScrBar || this._grid._hScrBar.scrollWidth == 0))))
			{
			    left += paddingLeft;
			}

			
			if ($util.IsIE)
				left += parentCell.firstChild.offsetLeft - parentCell.firstChild.scrollLeft;
			else if ($util.IsSafari || $util.IsChrome)
				left -= parentCell.firstChild.scrollLeft;
			else
			{
				left += parentCell.firstChild.firstChild.offsetLeft;
				

			}

			if (left < leftBounds)
			{
				width -= (leftBounds - left);
				evntArgs.customDisplay.leftCutOff = leftBounds - left;
				left = leftBounds;
			}
			if (left + width > rightBounds)
				width += rightBounds - (left + width);

			evntArgs.customDisplay.left = left;
			evntArgs.customDisplay.width = width;
			evntArgs.customDisplay.top = parentCell.parentNode.offsetTop + cellElement.parentNode.offsetTop;
		}

	},

	_onFilterCellEnteringEdit: function (evntArgs)
	{
		var cellElement = evntArgs.cell.get_element();
		var parentCell = this.__getColSpanTDFromUnfixedCell(cellElement);
		if (parentCell)
		{
			var cfDisplayOption = { cancel: null, top: null, left: null, height: null, width: null, text: null };
			var cfArgs = { cell: evntArgs.cell, customDisplay: cfDisplayOption };
			this._enteringEditMode(cfArgs);

			var leftDif = cellElement.offsetLeft - evntArgs.customDisplay.left;
			var widthDif = cellElement.offsetWidth - evntArgs.customDisplay.width;

			if (cfArgs.customDisplay.leftCutOff)
			{
				if (cfArgs.customDisplay.leftCutOff >= Math.abs(leftDif))
				{
					leftDif = 0;
					widthDif = 0;
				}
				else
				{
					leftDif += cfArgs.customDisplay.leftCutOff;
					widthDif -= cfArgs.customDisplay.leftCutOff;
				}
			}

			evntArgs.customDisplay.left = cfArgs.customDisplay.left - leftDif;
			evntArgs.customDisplay.width = cfArgs.customDisplay.width - widthDif;
			evntArgs.customDisplay.top = cfArgs.customDisplay.top;

		}
	},

	_getClassNameOnly: function (name)
	{
		var nameAr = name.split(".");
		if (nameAr.length > 2)
			return null;
		else if (nameAr.length == 2)
			return nameAr[1];
		else
			return name;
	},
	_getStyleSheet: function (name)
	{
		return $util.getStyleSheet(name);
	},

	_registerEnteringEditHandlerForBehaviors: function (behaviors)
	{
		if (!behaviors)
			return;
		for (var i = 0; i < behaviors._behaviors.length; i++)
		{
			var behavior = behaviors._behaviors[i];
			if (behavior)
			{
				//check and add
				if ($IG.GridEditBase && $IG.GridEditBase.isInstanceOfType(behavior) && (!$IG.Filtering || !$IG.Filtering.isInstanceOfType(behavior)))
					behavior._addEnteringEditEventListener(this._enteringEditModeHandler);

				if ($IG.IGridBehaviorContainer.isInstanceOfType(behavior))
				{
					var subBehCollection = behavior.get_behaviors();
					if (subBehCollection)
						this._registerEnteringEditHandlerForBehaviors(subBehCollection);
				}
			}
		}
	},

	_addingActiveRowCssClass: function (eventArgs)
	{
		if (eventArgs.row)
		{
			var rowElem = eventArgs.row.get_element();
			var index = rowElem ? this.__findColsSpanIndex(rowElem) : null;
			if (index != null)
			{
				var unfixedCells = this.__getUnfixedCellsFromTd(rowElem.childNodes[index]);
				if (unfixedCells && unfixedCells[0].parentNode)
					$util.addCompoundClass(unfixedCells[0].parentNode, eventArgs.cssClass);
			}
		}
	},
	_removingActiveRowCssClass: function (eventArgs)
	{
		if (eventArgs.row)
		{
			var rowElem = eventArgs.row.get_element();
			var index = rowElem ? this.__findColsSpanIndex(rowElem) : null;
			if (index != null)
			{
				var unfixedCells = this.__getUnfixedCellsFromTd(rowElem.childNodes[index]);
				if (unfixedCells && unfixedCells[0].parentNode)
					$util.removeCompoundClass(unfixedCells[0].parentNode, eventArgs.cssClass);
			}
		}
	},
	_initializeComplete: function ()
	{
		this._enteringEditModeHandler = Function.createDelegate(this, this._enteringEditMode);
		this._registerEnteringEditHandlerForBehaviors(this._grid.get_behaviors());

		this._activation = this._grid.get_behaviors().get_activation();
		if (this._activation)
		{
			this._addingActiveRowCssClassHandler = Function.createDelegate(this, this._addingActiveRowCssClass);
			this._grid._gridUtil._registerEventListener(this._activation, "AddingActiveRowCssClass", this._addingActiveRowCssClassHandler);

			this._removingActiveRowCssClassHandler = Function.createDelegate(this, this._removingActiveRowCssClass);
			this._grid._gridUtil._registerEventListener(this._activation, "RemovingActiveRowCssClass", this._removingActiveRowCssClassHandler);

			this._activation._addScrolledCellIntoViewEventHandler(Function.createDelegate(this, this._onScrolledCellIntoView));
			this._onKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
			this._grid._gridUtil._registerEventListener(this._grid, "KeyDown", this._onKeyDownHandler);
		}
		this._columnResizing = this._grid.get_behaviors().get_columnResizing();
		if (this._columnResizing)
			this._columnResizing._rebalanceContainerWidths = Function.createDelegate(this, this._rebalanceContainerWidths);
		this._virtualScrolling = this._grid.get_behaviors().get_virtualScrolling();
		if (this._virtualScrolling)
			this._virtualScrolling._addReceivedMoreRowsEventHandler(Function.createDelegate(this, this._onReceivedMoreRows));

		this._editingCore = this._grid.get_behaviors().get_editingCore();
		if (this._editingCore)
		{
			this._cellEditing = this._editingCore.get_behaviors().get_cellEditing();
			this._rowAdding = this._editingCore.get_behaviors().get_rowAdding();
			if (this._editingCore._batchUpdating)
			{
				this._onRemovingEmptyTemplateHandler = Function.createDelegate(this, this._onRemovingEmptyTemplate);
				this._grid._gridUtil._registerEventListener(this._grid, "RemovedEmptyTemplate", this._onRemovingEmptyTemplateHandler);

				this._onAddingCellsToBatchAddedRowHandler = Function.createDelegate(this, this._onAddingCellsToBatchAddedRow);
				this._grid._gridUtil._registerEventListener(this._grid, "NewBatchRowAddingCells", this._onAddingCellsToBatchAddedRowHandler);

				this._onBatchCellAddCssHandler = Function.createDelegate(this, this._onBatchCellAddCss);
				this._grid._gridUtil._registerEventListener(this._grid, "BatchCellAddCss", this._onBatchCellAddCssHandler);

				this._onRowAddedBatchHandler = Function.createDelegate(this, this._onRowAddedBatch);
				this._grid._gridUtil._registerEventListener(this._grid, "RowAddedBatch", this._onRowAddedBatchHandler);

				this._onBatchUpdateUndoneHandler = Function.createDelegate(this, this._onBatchUpdateUndone);
				this._grid._gridUtil._registerEventListener(this._grid, "BatchUpdateUndone", this._onBatchUpdateUndoneHandler);
			}
		}

		this._summaryRow = this._grid.get_behaviors().get_summaryRow();
		this._filtering = this._grid.get_behaviors().get_filtering();

		

		if ($util.IsSafari || this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
		{
			setTimeout(Function.createDelegate(this, this._forceGridResize), 0);
			

			if (this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters)
				setTimeout(Function.createDelegate(this, this._forceGridResize), 200);
		}

		
		var affectedColKey = this._get_clientOnlyValue("fscKey");
		if (affectedColKey && affectedColKey != "" && this._clientEvents["FixedStateChanged"])
		{
			var column = this._grid.get_columns().get_columnFromKey(affectedColKey);
			if (column)
			{
				var direction = this._get_clientOnlyValue("fscDir");
				var isFixed = this._get_clientOnlyValue("fscFixed");
				this._grid._raiseSenderClientEvent(this, this._clientEvents['FixedStateChanged'], new $IG.FixedEvenArgs(this.createFixedColumnObj(column, direction), isFixed));
			}
		}
	},

	

	_forceGridResize: function ()
	{
	    // N.R. April 14th, 2015 Bug #192312: JS error "Cannot read property '_onResize' of null" by clicking many times on fix/unfix button
	    if (this._grid != null) {
		    this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
	    }
	},

	_onReceivedMoreRows: function ()
	{
		if ($util.IsIE || $util.IsSafari)
		{
			var rows = this._grid._elements["rows"];
			delete this._grid._elements["rows"];
			this._grid.__walkThrough(rows, false);
			this._scrollDivs = this._grid._elements["unfixedDiv"];
		}
		this._grid._onResize({ "clientHeight": this._grid._element.clientHeight }, false);
	},

	_onRemovingEmptyTemplate: function (args)
	{
		if (args.tbodyRows)
			$util.addCompoundClass(args.tbodyRows, this._fixedCss);
	},

	_onAddingCellsToBatchAddedRow: function (args)
	{
		if (args.row)
		{
			args.cancel = true;
			var newRow = args.row;
			this._createRow(args, newRow);

		}
	},

	
	_createRow: function (args, newRow, isSizeRow, firstRow)
	{
		var origCells = firstRow ? firstRow.childNodes : [], subCells;
		
		var cellOffset = this._grid._cell_index_offset;
		if (isSizeRow && firstRow)
		{
			for (var x = 0; x < cellOffset; ++x)
			{
				var td = document.createElement('th');
				if ($util.IsIE)
					td.appendChild(document.createComment(''));
				this._grid.__copyTD(td, origCells[x]);
				newRow.appendChild(td);
			}
		}
		for (var x = 0; x < this._leftFixedDataColCount; ++x)
		{
			var td = document.createElement('td');
			if ($util.IsIE)
				td.appendChild(document.createComment(''));
			if (isSizeRow && firstRow)
				this._grid.__copyTD(td, origCells[x + cellOffset]);
			newRow.appendChild(td);
		}

		var unfixedTD = document.createElement('td');
		if (isSizeRow && firstRow)
			this._grid.__copyTD(unfixedTD, origCells[this._grid._cell_index_offset + this._leftFixedDataColCount]);
		var tBodyClass = this._get_clientOnlyValue("fcscc");
		tBodyClass = tBodyClass.substr(tBodyClass.indexOf('.') + 1);
		unfixedTD.className = tBodyClass;
		unfixedTD.setAttribute('colspan', this._unfixedCount);
		
		unfixedTD.colSpan = this._unfixedCount;
		newRow.appendChild(unfixedTD);
		var div = document.createElement('div');
		div.style.overflow = 'hidden';
		if ($util.IsIE6)
			div.style.width = '100%';
		if (!$util.IsIE)
			div.style.position = 'relative';
		div.setAttribute('mkr', 'unfixedDiv');
		div.setAttribute('nw', '7');
		var table = document.createElement('table');
		table.setAttribute('border', '0');
		table.setAttribute('cellSpacing', '0');
		table.setAttribute('cellPadding', '0');
		table.style.width = '100%';
		table.style.height = '100%';
		table.style.tableLayout = 'fixed';
		if (!$util.IsIE)
			table.style.position = 'relative';
		if (!$util.IsIE && !$util.IsSafari)
		{
			var tableScrollClass = this._get_clientOnlyValue("sdcc");
			tableScrollClass = tableScrollClass.substr(tableScrollClass.indexOf('.') + 1);
			table.className = tableScrollClass;
		}
		var tBody = document.createElement('tbody');
		tBody.className = args.itemCssClass;
		var fixedTR = document.createElement('tr');
		for (var x = 0; x < this._unfixedCount; ++x)
		{
			var td = document.createElement('td');
			if ($util.IsIE)
				td.appendChild(document.createComment(''));
			if (isSizeRow && firstRow)
			{
				if (!subCells)
					subCells = origCells[this._grid._cell_index_offset + this._leftFixedDataColCount].childNodes[0].childNodes[0].childNodes[0].childNodes[0].childNodes;
				this._grid.__copyTD(td, subCells[x]);
			}
			fixedTR.appendChild(td);
		}
		tBody.appendChild(fixedTR);
		table.appendChild(tBody);
		div.appendChild(table);
		this._scrollDivs[this._scrollDivs.length] = div;
		
		this._ensureScrollHandler(div);
		unfixedTD.appendChild(div);

		for (var x = 0; x < this._rightFixedDataColCount; ++x)
		{
			var td = document.createElement('td');
			if ($util.IsIE)
				td.appendChild(document.createComment(''));
			if (isSizeRow && firstRow)
				this._grid.__copyTD(td, origCells[origCells.length - this._rightFixedDataColCount + x]);
			newRow.appendChild(td);
		}
	},

	_onBatchCellAddCss: function (args)
	{
		if (args.cellElement)
		{
			var widthCss = this._get_clientOnlyValue(args.key + "_cw");
			widthCss = widthCss.substr(widthCss.indexOf('.') + 1);
			$util.addCompoundClass(args.cellElement, widthCss);
		}
	},
	_onCreatingSizeRow: function (args)
	{
		if (args.firstRow)
		{
			args.cancel = true;
			var newRow = args.sizeRow;
			args.itemCssClass = args.firstRow.parentNode.className;
			this._createRow(args, newRow, true, args.firstRow);

		}
	},

	_onRowAddedBatch: function (args)
	{
		if (this._grid.get_rows().get_length() == 1)
			this._resizeSeparators();
	},

	_onBatchUpdateUndone: function (args)
	{
		if (args.type == $IG.RowUpdateType.Add && this._grid.get_rows().get_length() == 0)
			this._resizeSeparators();
	},

	_onCalculatingAdjacent: function (args)
	{
		var footerInfo, siblingInfo, col;
		if (this._grid._hasHeaderLayout)
		{
			col = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(args.column._key);
			while (col._get_parent && col._get_parent()._get_parent)
				col = col._get_parent();
			footerInfo = this.getFixedColumnFromKey(col._key);
			col = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(args.sibling._key);
			while (col._get_parent && col._get_parent()._get_parent)
				col = col._get_parent();
			siblingInfo = this.getFixedColumnFromKey(col._key);
		}
		else
		{
			footerInfo = this.getFixedColumnFromKey(args.column._key);
			siblingInfo = this.getFixedColumnFromKey(args.sibling._key);
		}
		if (footerInfo != null && siblingInfo != null)
			return footerInfo.get_fixLocation() == siblingInfo.get_fixLocation();
		return footerInfo == null && siblingInfo == null;
	},

	_onStylesHaveBeenAppended: function ()
	{
		
		this.__createScrollStyleSheet();
		this._scrollStyleSheet.left = (-this._grid.get_scrollLeft()) + "px";
	},
	

	
	__createSpaceForSeparators: function ()
	{
		try
		{
			if (this._leftSeparator && this._stopperStyleCss)
			{
				this._stopperStyleCss.paddingLeft = (this._leftFixedCount ? this._leftSeparator.clientWidth : 0) + "px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingLeft = (this._leftFixedCount ? this._leftSeparator.clientWidth : 0) + "px";
			}
			else if (this._stopperStyleCss && this._stopperStyleCss.paddingLeft != "0px")
			{
				this._stopperStyleCss.paddingLeft = "0px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingLeft = "0px";
			}

			if (this._rightSeparator && this._stopperStyleCss)
			{
				this._stopperStyleCss.paddingRight = this._rightSeparator.clientWidth + "px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingRight = this._rightSeparator.clientWidth + "px";
			}
			else if (this._stopperStyleCss && this._stopperStyleCss.paddingRight != "0px")
			{
				this._stopperStyleCss.paddingRight = "0px";
				if (this._captionStopperStyleCss)
					this._captionStopperStyleCss.paddingRight = "0px";
			}
		}
		catch (e)
		{
		}
	},

	__getFirstScrollDiv: function ()
	{
		if (!this._scrollDivs)
			return null;
		
		return (this._scrollDivs.length != undefined ? this._scrollDivs[0] : this._scrollDivs);
	},

	__createTransportableFixedColumnObj: function (columnKey, fixLocation)
	{
		var info = new Object();
		info.columnKey = columnKey;
		info.fixLocation = fixLocation;
		return info;
	},
	__createScrollStyleSheet: function ()
	{
		var className = this._get_clientOnlyValue("sdcc");
		if (className)
			this._scrollStyleSheet = this._getStyleSheet(className);
	},
	__initializeFixedColumns: function ()
	{
		var fixedCols = this._get_value($IG.GridColumnFixingProps.FixedColumns);
		if (fixedCols)
		{
			for (var i = 0; i < fixedCols.length; i++)
			{
				var column = this._owner._columns.get_columnFromKey(fixedCols[i][0]);
				if (this._grid._hasHeaderLayout)
				{
					var layoutColumn = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(fixedCols[i][0]);
					layoutColumn._fixedDirection = fixedCols[i][1];
					if (!column)
						column = layoutColumn;
				}

				column._fixedDirection = fixedCols[i][1];
				this._fixedColumns[this._fixedColumns.length] = new $IG.FixedColumnInfo(column, column._fixedDirection);

			}
		}
	},

	__initializeColumnWidthCssClasses: function ()
	{
		var gridCols = this._owner.get_columns();
		var midRegion = [];
		var leftRegion = [];
		var rightRegion = [];
		var defaultColWidth = this._owner.get_defaultColumnWidth();
		for (var i = 0; i < gridCols.get_length(); i++)
		{
			var column = gridCols.get_column(i);
			var className = this._get_clientOnlyValue(column._key + "_cw");
			if (className)
			{
				column._columnWidthCssClass = className;
				var columnStyle = this._getStyleSheet(className);
				if (columnStyle)
				{
					if (column.get_width() != "" && columnStyle.width != column.get_width())
						columnStyle.width = column.get_width();
					else if (column.get_width() == "" && columnStyle.width != defaultColWidth)
						columnStyle.width = defaultColWidth;
				}
			}
			if (!this._grid._hasHeaderLayout)
			{
				if (column._fixedDirection == $IG.FixLocation.Left)
					leftRegion[leftRegion.length] = column.get_headerElement();
				else if (column._fixedDirection == $IG.FixLocation.Right)
					rightRegion[rightRegion.length] = column.get_headerElement();
				else
					midRegion[midRegion.length] = column.get_headerElement();
			}
		}
		if (this._grid._hasHeaderLayout)
		{
			var columns = this._grid.get_headerColumnsLayout();
			for (var i = 0; i < columns.length; i++)
			{
				var column = columns[i];
				var rgn = null;
				if (column._fixedDirection == $IG.FixLocation.Left)
					rgn = leftRegion;
				else if (column._fixedDirection == $IG.FixLocation.Right)
					rgn = rightRegion;
				else
					rgn = midRegion;

				this.__addChildColsToRegion(rgn, column, column._fixedDirection);
			}
		}
		if (leftRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = leftRegion;
		if (midRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = midRegion;
		if (rightRegion.length > 0)
			this._headerRegions[this._headerRegions.length] = rightRegion;
	},
	__addChildColsToRegion: function (region, column, fixedDir)
	{
		region[region.length] = column.get_headerElement();
		if (column._fixedDirection != fixedDir)
			column._parentFixedDir = fixedDir;
		if (column.get_isGroupField())
		{
			var childCols = column.get_columns();
			for (var j = 0; j < childCols.length; j++)
				this.__addChildColsToRegion(region, childCols[j], fixedDir);
		}
	},
	__unfixedCellHeightTimer: null,
	__onUnfixedHeightTimerExpire: function ()
	{
		this.__unfixedCellHeightTimer = null;
	},

	__findColsSpanIndex: function (row)
	{
		for (var i = this._grid._get_cellIndexOffset(); i < row.childNodes.length; i++)
		{
			var cell = row.childNodes[i];
			if (cell && cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || $util._isXAttrContains(cell.firstChild, "mkr:unfixedDiv")))
			{
				return i;
			}
		}
		return null;
	},

	__alignPixeledStatCaption: function (cells, captionCells, existingTableWidth, reverse)
	{
		var itr = 0;
		for (var i = 0; i < cells.length; i++)
		{
			var cell = cells[i];
			var caption = (captionCells && captionCells.length && itr < captionCells.length) ? captionCells[itr] : null;
			if (cell.style.width != "" && cell.style.width.indexOf("%") < 0 && cell.offsetWidth > 0)
			{
				

				var pxIndex = cell.style.width.indexOf("px");
				if (pxIndex > -1 && existingTableWidth)
				{
				    // Z.K. 14th September, 2016 Fixing Bug #225303 - Performance issue when using IE11 with 200 columns and a lot of behaviors
					var neededWidth = parseInt(cell.style.width);
					if (!isNaN(neededWidth))
					{
						//cell.style.width = neededWidth + 1 + "px";
						cell.style.width = neededWidth + "px";
					}
				}

			    // Z.K. 19/09/17 Fixing Bug #239897 - Header, data and new row column alignments get disordered when several conditions are met.
				if (caption &&
                    ((!reverse && caption.getAttribute && caption.getAttribute("mkr") != "fxdCapThLeft"
                            && caption.getAttribute("mkr") != "fxdCapThRight" && caption.getAttribute("mkr") != "unfxdCapTh") ||
				        (reverse && cell.getAttribute && cell.getAttribute("mkr") != "fxdCapThLeft"
                            && cell.getAttribute("mkr") != "fxdCapThRight" && cell.getAttribute("mkr") != "unfxdCapTh")))
				{
				    if (!(caption.getAttribute("mkr") == "fxdCapThLeft" || caption.getAttribute("mkr") == "fxdCapThRight")) {
				        $util.setAbsoluteWidth(caption, cell.offsetWidth);
				        // Z.K. 19/06/18 Fixing Bug 250151 - Browser stops responding when the window is resized if the grid has some fixed columns.
				        if (i == cells.length - 1) {
				            this._forceGridResize();
				        }
				    }
					
					//if ($util.IsIE7 && caption.offsetWidth != cell.offsetWidth)
					//	$util.setAbsoluteWidth(caption, cell.offsetWidth);
				}
			}
			

			else
			{
				if (caption)
					caption.style.width = "";
			}

			var unfixedCells = reverse ? this.__getUnfixedCellsFromTh(cell) : this.__getUnfixedCellsFromTd(cell);

			
			if (unfixedCells)
			{
				var unfixedCaption = this.__getUnfixedCellsFromTh(caption);
				
				if (unfixedCaption == null)
					unfixedCaption = this.__getUnfixedCellsFromTd(caption);
				this.__alignPixeledStatCaption(unfixedCells, unfixedCaption, existingTableWidth, reverse);
			}
			else if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) &&
				((!reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThLeft" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThLeft" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl")))
			{
			    var newCaps = (reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				var cellSubset = [];
				var needSubset = true;
				if ((reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThLeft" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(!reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThLeft" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl"))
				{
					needSubset = false;
					cellSubset = (!reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				}
				else
				{
					for (var j = (newCaps.length + this._grid._get_cellIndexOffset()) - 1; j - i > -1; j--)
					{
						
						if (reverse && captionCells[j])
						    cellSubset.unshift(captionCells[j]);
					    // NR 27/08/18 Fixing Bugs:
					    // #239897 - Header, data and new row column alignments get disordered when several conditions are met.
					    // #256810 - When there are fixed columns and filtering aligment is Buttom after filter filter cells width is not correct
						if (!reverse && cells[j])
						    cellSubset.unshift(cells[j]);
					}
				}

				if (!reverse)
				{
				    // S.A Jan-29-2018 247931 - setting the fixed caption width to 1 and then back to the required width, 
				    // causes headres misallignment (shift) in some cases (i.e after a postback if grid is scrolled to the right)
				    //$util.setAbsoluteWidth(caption, 1);
					this.__alignPixeledStatCaption(cellSubset, newCaps, existingTableWidth, reverse);
					$util.setAbsoluteWidth(caption, caption.firstChild.offsetWidth);
					if (needSubset)
						i = newCaps.length + i - 1;
				}
				else
				{
					this.__alignPixeledStatCaption(newCaps, cellSubset, existingTableWidth, reverse);
					if (needSubset)
						itr = newCaps.length - 1;
				}

			}
			else if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) &&
				((!reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThRight" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThRight" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl")))
			{
				var newCaps = (reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				var cellSubset = [];
				var needSubset = true;
				if ((reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThRight" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(!reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThRight" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl"))
				{
					needSubset = false;
					cellSubset = (!reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				}
				else
				{
					var start = (reverse ? captionCells.length - 1 : newCaps.length + i - 1);
					var end = (reverse ? itr - 1 : i - 1)
					for (var j = start; j > end; j--)
					{
						
						if (reverse && captionCells[j])
						    cellSubset.unshift(captionCells[j]);
					    // NR 27/08/18 Fixing Bugs:
					    // #239897 - Header, data and new row column alignments get disordered when several conditions are met.
					    // #256810 - When there are fixed columns and filtering aligment is Buttom after filter filter cells width is not correct
						if (!reverse && cells[j])
						    cellSubset.unshift(cells[j]);
					}
				}

				if (!reverse)
				{
				    // S.A Jan-29-2018 247931 - setting the fixed caption width to 1 and then back to the required width, 
				    // causes headres misallignment (shift) in some cases (i.e after a postback if grid is scrolled to the right)
					//$util.setAbsoluteWidth(caption, 1);
					this.__alignPixeledStatCaption(cellSubset, newCaps, existingTableWidth, reverse);
					$util.setAbsoluteWidth(caption, caption.firstChild.offsetWidth);
					if (needSubset)
						i = newCaps.length - 1;
				}
				else
				{
					this.__alignPixeledStatCaption(newCaps, cellSubset, existingTableWidth, reverse);
					if (needSubset)
						itr = newCaps.length - 1;
				}
			}
			itr++;
		}
	},

	__alignNonePixeledStatCaption: function (cells, captionCells, reverse)
	{
		var itr = 0;
		for (var i = 0; i < cells.length; i++)
		{
			var cell = cells[i];
			var caption = (captionCells && captionCells.length && itr < captionCells.length) ? captionCells[itr] : null;
			if ((cell.style.width == "" && !this.__isColSpanForUnfixedCols(cell)) || cell.style.width.indexOf("%") > -1 && cell.offsetWidth > 0)
			{
				if (caption && ((!reverse && caption.getAttribute && caption.getAttribute("mkr") != "fxdCapThLeft" && caption.getAttribute("mkr") != "fxdCapThRight" && caption.getAttribute("mkr") != "unfxdCapTh") ||
				(reverse && cell.getAttribute && cell.getAttribute("mkr") != "fxdCapThLeft" && cell.getAttribute("mkr") != "fxdCapThRight" && cell.getAttribute("mkr") != "unfxdCapTh")))
				{
					$util.setAbsoluteWidth(caption, cell.offsetWidth);
				}
			}

			var unfixedCells = reverse ? this.__getUnfixedCellsFromTh(cell) : this.__getUnfixedCellsFromTd(cell);

			
			if (unfixedCells)
			{
				var unfixedCaption = this.__getUnfixedCellsFromTh(caption);
				
				if (unfixedCaption == null)
					unfixedCaption = this.__getUnfixedCellsFromTd(caption);

				this.__alignNonePixeledStatCaption(unfixedCells, unfixedCaption, reverse);
			}
			else if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) &&
				((!reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThLeft" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThLeft" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl")))
			{
				var newCaps = (reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				var cellSubset = [];
				var needSubset = true;
				if ((reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThLeft" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(!reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThLeft" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl"))
				{
					needSubset = false;
					cellSubset = (!reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				}
				else
				{
					for (var j = (newCaps.length + this._grid._get_cellIndexOffset()); j - i > -1; j--)
					{
						
						if (reverse && captionCells[j])
							cellSubset.unshift(captionCells[j]);
						else if (!reverse && cells[j])
							cellSubset.unshift(cells[j]);
					}
				}

				if (!reverse)
				{
				    // S.A Jan-29-2018 247931 - setting the fixed caption width to 1 and then back to the required width, 
				    // causes headres misallignment (shift) in some cases (i.e after a postback if grid is scrolled to the right)
				    //$util.setAbsoluteWidth(caption, 1);
					this.__alignNonePixeledStatCaption(cellSubset, newCaps, reverse);
					$util.setAbsoluteWidth(caption, caption.firstChild.offsetWidth);
					if (needSubset)
						i = newCaps.length - 1;
				}
				else
				{
					this.__alignNonePixeledStatCaption(newCaps, cellSubset, reverse);
					if (needSubset)
						itr = newCaps.length + i - 1;
				}

			}
			else if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) &&
				((!reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThRight" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThRight" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl")))
			{
				var newCaps = (reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				var cellSubset = [];
				var needSubset = true;
				if ((reverse && caption && caption.getAttribute && caption.getAttribute("mkr") == "fxdCapThRight" && caption.firstChild && caption.firstChild.nodeName == "TABLE" && caption.firstChild.getAttribute("mkr") == "fxdCaptnTbl") ||
				(!reverse && cell && cell.getAttribute && cell.getAttribute("mkr") == "fxdCapThRight" && cell.firstChild && cell.firstChild.nodeName == "TABLE" && cell.firstChild.getAttribute("mkr") == "fxdCaptnTbl"))
				{
					needSubset = false;
					cellSubset = (!reverse ? cell.firstChild.firstChild.rows[0].childNodes : caption.firstChild.firstChild.rows[0].childNodes);
				}
				else
				{
					var start = (reverse ? captionCells.length - 1 : newCaps.length + i - 1);
					var end = (reverse ? itr - 1 : i - 1)
					for (var j = start; j > end; j--)
					{
						
						if (reverse && captionCells[j])
							cellSubset.unshift(captionCells[j]);
						else if (!reverse && cells[j])
							cellSubset.unshift(cells[j]);
					}
				}

				if (!reverse)
				{
				    // S.A Jan-29-2018 247931 - setting the fixed caption width to 1 and then back to the required width, 
				    // causes headres misallignment (shift) in some cases (i.e after a postback if grid is scrolled to the right)
					//$util.setAbsoluteWidth(caption, 1);
					this.__alignNonePixeledStatCaption(cellSubset, newCaps, reverse);
					$util.setAbsoluteWidth(caption, caption.firstChild.offsetWidth);
					if (needSubset)
						i = newCaps.length - 1;
				}
				else
				{
					this.__alignNonePixeledStatCaption(newCaps, cellSubset, reverse);
					if (needSubset)
						itr = newCaps.length - 1;
				}
			}
			itr++;
		}
	},

	__isColSpanTDForUnfixedCols: function (cell)
	{
		if (cell && cell.tagName == "TD" && this.__isColSpanForUnfixedCols(cell))
			return true;
		else
			return false;
	},
	__isColSpanTHForUnfixedCols: function (cell)
	{
		if (cell && cell.tagName == "TH" && this.__isColSpanForUnfixedCols(cell))
			return true;
		else
			return false;
	},
	__isColSpanForUnfixedCols: function (cell)
	{
		if (cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || $util._isXAttrContains(cell.firstChild, "mkr:unfixedDiv")))
			return true;
		else
			return false;
	},
	__isUnfixedTD: function (elem)
	{
		var parentNode = (elem && elem.tagName == "TD" && elem.parentNode && elem.parentNode.parentNode && elem.parentNode.parentNode.parentNode ?
			elem.parentNode.parentNode.parentNode.parentNode :
			null);
		if (parentNode && parentNode.tagName == "DIV" &&
			(parentNode.getAttribute("mkr") == "unfixedDiv" || $util._isXAttrContains(parentNode, "mkr:unfixedDiv")))
			return true;
		else
			return false;
	},
	__isFixedLeftCap: function (elem)
	{
		var parentNode = (elem && elem.tagName == "TD" && elem.parentNode && elem.parentNode.parentNode && elem.parentNode.parentNode.parentNode ?
			elem.parentNode.parentNode.parentNode.parentNode :
			null);
		if (parentNode && parentNode.tagName == "TD" &&
			(parentNode.getAttribute("mkr") == "fxdCapThLeft" || $util._isXAttrContains(parentNode, "mkr:fxdCapThLeft")))
			return true;
		else
			return false;
	},
	__isFixedRightCap: function (elem)
	{
		var parentNode = (elem && elem.tagName == "TD" && elem.parentNode && elem.parentNode.parentNode && elem.parentNode.parentNode.parentNode ?
			elem.parentNode.parentNode.parentNode.parentNode :
			null);
		if (parentNode && parentNode.tagName == "TD" &&
			(parentNode.getAttribute("mkr") == "fxdCapThRight" || $util._isXAttrContains(parentNode, "mkr:fxdCapThRight")))
			return true;
		else
			return false;
	},
	__getUnfixedCellsFromTd: function (cell)
	{
		if (this.__isColSpanTDForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0].childNodes;
		return null;
	},
	__getTRElemForUnfixedCellsFromSpanTd: function (cell)
	{
		if (this.__isColSpanTDForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0];
		return null;
	},
	__getUnfixedCellsFromTh: function (cell)
	{
		if (this.__isColSpanTHForUnfixedCols(cell))
			return cell.firstChild.firstChild.rows[0].childNodes;
		return null;
	},

	__getColSpanTDFromUnfixedCell: function (cell)
	{
		if (this.__isUnfixedTD(cell))
			return cell.parentNode.parentNode.parentNode.parentNode.parentNode;
		return null;
	},
	

	
	_rebalanceContainerWidths: function ()
	{

	},
	findRowIndexByCellElem: function (elem)
	{
		if (this.__isUnfixedTD(elem))
			elem = elem.parentNode.parentNode.parentNode.parentNode.parentNode;

		var obj = $util.resolveMarkedElement(elem.parentNode);
		if (obj)
		{
			var type = obj[0].getAttribute("type");
			if (type == "row")
				return obj[1];
		}
		return null;
	},

	_getGridCellFromElement: function (element)
	{
		if (this.__isUnfixedTD(element) || this.__isFixedLeftCap(element) || this.__isFixedRightCap(element))
			return element;
		else
		{
			while (element && (element.tagName != "TD" && element.tagName != "TH" || (!$util._getXAttr(element.parentNode) || !$util._isXAttrContains(element.parentNode, "adr")) && element.parentNode.getAttribute("adr") === null)) //TH for row selectors
				element = element.parentNode;
			return element;
		}
	},

	_get_cellElementByIndex: function (args)
	{
		args.cancel = true;
		var row = args.rowElement;
		var index = args.index;

		args.cellElement = this.__get_cellElementByIndex(row, index);
	},

	__get_cellElementByIndex: function (row, index)
	{
		var i = this._grid._get_cellIndexOffset();
		var j = i;
		var oldI = null;
		var oldRow = row;

		if ((this._grid._hasHeaderLayout && row.getAttribute("mkr") == "filterRow" && this._grid.get_behaviors().get_filtering().get_alignment() == $IG.FilteringAlignment.Top) || (this._grid._hasMultiColumnFooters && row.getAttribute("mkr") == "filterRow" && this._grid.get_behaviors().get_filtering().get_alignment() == $IG.FilteringAlignment.Bottom))
		{
			index -= i;
			var columnFixing = this._grid.get_behaviors().get_columnFixing();
			if (index < columnFixing._leftFixedDataColCount)
				return this._grid._elements["filterRowLeft"].childNodes[index];
			else if (index >= columnFixing._leftFixedDataColCount + columnFixing._unfixedDataColCount && columnFixing._rightFixedDataColCount > 0)
				return this._grid._elements["filterRowRight"].childNodes[index - columnFixing._leftFixedDataColCount - columnFixing._unfixedDataColCount];
			else
				index = index + i - columnFixing._leftFixedDataColCount + (columnFixing._leftFixedDataColCount > 0 ? 1 : 0);
		}
		if ((this._grid._hasHeaderLayout && row.getAttribute("mkr") == "addNewRow" && this._grid.get_behaviors().get_editingCore().get_behaviors().get_rowAdding().get_alignment() == $IG.AddNewRowAlignment.Top) || (this._grid._hasMultiColumnFooters && row.getAttribute("mkr") == "addNewRow" && this._grid.get_behaviors().get_editingCore().get_behaviors().get_rowAdding().get_alignment() == $IG.AddNewRowAlignment.Bottom))
		{
			index -= i;
			var columnFixing = this._grid.get_behaviors().get_columnFixing();
			if (index < columnFixing._leftFixedDataColCount)
				return this._grid._elements["addNewRowLeft"].childNodes[index];
			else if (index >= columnFixing._leftFixedDataColCount + columnFixing._unfixedDataColCount && columnFixing._rightFixedDataColCount > 0)
				return this._grid._elements["addNewRowRight"].childNodes[index - columnFixing._leftFixedDataColCount - columnFixing._unfixedDataColCount];
			else
				index = index + i - columnFixing._leftFixedDataColCount + (columnFixing._leftFixedDataColCount > 0 ? 1 : 0);
		}

		do
		{
			
			if (i >= row.childNodes.length && oldI != null)
			{
				i = oldI;
				oldI = null;
				row = oldRow;
			}
			var cell = row.childNodes[i];

			if (cell && cell.colSpan && cell.firstChild && cell.firstChild.tagName == "DIV" &&
			(cell.firstChild.getAttribute("mkr") == "unfixedDiv" || $util._isXAttrContains(cell.firstChild, "mkr:unfixedDiv")))
			{
				oldI = i + 1;
				i = 0;
				row = cell.firstChild.firstChild.rows[0];
			}
			else
			{
				j++;
				i++;
			}
		}
		while (j <= index);

		return row.childNodes[i - 1];
	},

	getCellIndexFromElem: function (elem)
	{
		var spanTd = null;
		var indexAdj = 0;

		if (this.__isUnfixedTD(elem))
		{
			spanTd = elem.parentNode.parentNode.parentNode.parentNode.parentNode;
			if (spanTd.parentNode && this._leftFixedDataColCount > 0 &&
				((spanTd.parentNode.getAttribute("mkr") == "filterRow" && this._grid.get_behaviors().get_filtering().get_alignment() == $IG.FilteringAlignment.Top && this._grid._hasHeaderLayout) ||
				(spanTd.parentNode.getAttribute("mkr") == "addNewRow" && this._grid.get_behaviors().get_editingCore().get_behaviors().get_rowAdding().get_alignment() == $IG.AddNewRowAlignment.Top && this._grid._hasHeaderLayout) ||
				(spanTd.parentNode.getAttribute("mkr") == "filterRow" && this._grid.get_behaviors().get_filtering().get_alignment() == $IG.FilteringAlignment.Bottom && this._grid._hasMultiColumnFooters) ||
				(spanTd.parentNode.getAttribute("mkr") == "addNewRow" && this._grid.get_behaviors().get_editingCore().get_behaviors().get_rowAdding().get_alignment() == $IG.AddNewRowAlignment.Bottom && this._grid._hasMultiColumnFooters)))
				indexAdj = this._leftFixedDataColCount - 1;
		}
		else if (this.__isFixedLeftCap(elem))
			spanTd = elem.parentNode.parentNode.parentNode.parentNode;
		else if (this.__isFixedRightCap(elem))
		{
			spanTd = elem.parentNode.parentNode.parentNode.parentNode;
			if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) && (elem.parentNode.getAttribute("mkr") == "filterRowRight" || elem.parentNode.getAttribute("mkr") == "addNewRowRight"))
				indexAdj = this._leftFixedDataColCount + this._unfixedDataColCount - (this._leftFixedDataColCount > 0 ? 1 : 0) - (this._unfixedDataColCount > 0 ? 1 : 0);
		}
		if (spanTd)
			return this._grid._gridUtil.getCellIndex(spanTd) + this._grid._gridUtil.getCellIndex(elem) - this._grid._get_cellIndexOffset() + indexAdj;
		else
		{
			var indexWithoutOffset = this._grid._gridUtil.getCellIndex(elem) - this._grid._get_cellIndexOffset();
			if (indexWithoutOffset < (this._grid._hasHeaderLayout ? this._leftFixedDataColCount : this._leftFixedCount))
				return indexWithoutOffset;
			else
			{
				var unfixedCount = (this._grid._hasHeaderLayout ? this._unfixedDataColCount : this._unfixedCount)
				return indexWithoutOffset + (unfixedCount > 0 ? unfixedCount - 1 : 0);
			}
		}
	},

	scrollCellIntoViewIE: function (cell)
	{
		var elem = cell.get_element();
		var row = cell.get_row();

		
		if ($util.IsOpera)
		{
			
			var topFix = this._grid._marginTop;
			var elemVertical = this.__isUnfixedTD(elem) ? this.__getColSpanTDFromUnfixedCell(elem) : elem;
			var scrollContainerVertical = this._grid._elements["container"];
			var bounds = Sys.UI.DomElement.getBounds(elemVertical);
			var scrollTop = scrollContainerVertical.scrollTop - topFix;
			var scrollBoundsVertical = (scrollTop + scrollContainerVertical.offsetHeight);
			var elemBoundsVertical = elemVertical.offsetTop + bounds.height;
			var vScrBar = this._grid._elements["vScrBar"];

			

			if (!this._grid._isAuxRow(row) && vScrBar && (elemVertical.offsetHeight > scrollBoundsVertical ||
						elemBoundsVertical < scrollTop ||
						elemVertical.offsetTop <= scrollBoundsVertical && elemBoundsVertical > scrollBoundsVertical ||
						elemVertical.offsetTop <= scrollTop && elemBoundsVertical >= scrollTop
						))
			{
				scrollTop = elemBoundsVertical - (scrollContainerVertical.offsetHeight) + topFix;
				vScrBar.scrollTop = scrollTop;
			}
		}

		if (this.__isUnfixedTD(elem))
		{
			var scrollContainer = elem.parentNode.parentNode.parentNode.parentNode;
			var scrollLeft = scrollContainer.scrollLeft;
			var bounds = Sys.UI.DomElement.getBounds(elem);
			var scrollBounds = (scrollLeft + scrollContainer.offsetWidth);
			var elemBounds = elem.offsetLeft + bounds.width;

			if (elem.offsetLeft > scrollBounds ||
						elemBounds < scrollLeft ||
						elem.offsetLeft <= scrollBounds && elemBounds > scrollBounds ||
						elem.offsetLeft <= scrollLeft && elemBounds >= scrollLeft
						)
			{
				scrollLeft = elemBounds - (scrollContainer.offsetWidth);
			}

			
			if (this._grid._hScrBar)
				this._grid._hScrBar.scrollLeft = scrollLeft;

			var delegate = Function.createDelegate(this, this._onGridScrolled);
			$addHandler(scrollContainer, "scroll", delegate);
			elem.focus();
			$removeHandler(scrollContainer, "scroll", delegate);
		}
		else
		{
			if (elem)
				elem.focus();
		}
	},
	_onCellScrollToView: function (args)
	{
		var cell = args.cell;
		var elem = cell.get_element();
		var row = cell.get_row();
		if (this.__isUnfixedTD(elem))
		{
			var scrollContainer = elem.parentNode.parentNode.parentNode.parentNode;
			var scrollLeft = scrollContainer.scrollLeft;
			var bounds = Sys.UI.DomElement.getBounds(elem);
			var scrollBounds = (scrollLeft + scrollContainer.offsetWidth);
			var elemBounds = elem.offsetLeft + bounds.width;

			if (elem.offsetLeft > scrollBounds ||
						elemBounds < scrollLeft ||
						elem.offsetLeft <= scrollBounds && elemBounds > scrollBounds ||
						elem.offsetLeft <= scrollLeft && elemBounds >= scrollLeft
						)
			{
				scrollLeft = elemBounds - (scrollContainer.offsetWidth);
			}

			
			if (this._grid._hScrBar)
				this._grid._hScrBar.scrollLeft = scrollLeft;

			return true;
		}
		return false;
	},
	
	// When cell has focusable template and cell is out of view (horizontal scroll of grid), then
	// tab-key may trigger getting focus by template and browser will scroll that template into view.
	// In that situation browser first scrolls first container of that template, which is DIV container in row (td->div->table->tr->td->template) in grid.
	// But main scroller of grid and sibling rows (with their divs) are not aware about that auto-scroll by browser and layout is destroyed.
	// To get around process scroll for each DIV and trigger scroll to the same value/scrollLeft for main grid.
	// That will trigger synchronization of grid-header-scroll, and scrolls for all siblings.
	_ensureScrollHandler: function (div)
	{
		var me = this;
		div.onscroll = function (e)
		{
			div = e ? e.target : null;
			// main scroller of grid
			var hsb = me._grid._hScrBar;
			if (!div || !hsb || hsb.offsetHeight < 5)
			    return;
			// _gridScrolledTime is set by _onGridScrolled on scroll-of-main-grid.
			// do not trigger synchronization when grid is scrolled by its scroller.
			
			var left = div.scrollLeft; //, t = me._gridScrolledTime, t0 = new Date().getTime();
			if (!me._grid._ignoreCScroll && left != hsb.scrollLeft)
			{
			    
			    if ($util.IsFireFox)
			        div.scrollLeft = 0;
			    hsb.scrollLeft = left;
			}
		}
	},
	_addStyleToRow: function (rowElem, cssClass)
	{
		$util.addCompoundClass(rowElem, cssClass);
		for (var x = 0; x < rowElem.childNodes.length; ++x)
		{
			var child = rowElem.childNodes[x];
			if (this.__isColSpanTDForUnfixedCols(child))
			{
				var innerRow = this.__getTRElemForUnfixedCellsFromSpanTd(child);
				if (innerRow)
					$util.addCompoundClass(innerRow, cssClass);
				break;
			}
		}
	},

	_removeStyleFromRow: function (rowElem, cssClass)
	{
		$util.removeCompoundClass(rowElem, cssClass);
		for (var x = 0; x < rowElem.childNodes.length; ++x)
		{
			var child = rowElem.childNodes[x];
			if (this.__isColSpanTDForUnfixedCols(child))
			{
				var innerRow = this.__getTRElemForUnfixedCellsFromSpanTd(child);
				if (innerRow)
					$util.removeCompoundClass(innerRow, cssClass);
				break;
			}
		}
	}
	


}

$IG.ColumnFixing.registerClass('Infragistics.Web.UI.ColumnFixing', $IG.GridBehavior, $IG.IColumnSettings, $IG.IColumnFixingBehavior);


$IG.ColumnFixingSettings = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnFixingSettings">
	/// Object that defines a column fixing setting for the grid column.
	/// </summary>
	$IG.ColumnFixingSettings.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnFixingSettings.prototype =
{
	get_enabled: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.enabled">
		/// Indicates whether column fixing is enabled on the particular column.
		/// </summary>
		/// <returns type="boolean">True if fixing is enabled for the column, false otherwise</returns>

		return this._get_clientOnlyValue("cfse");
	},

	get_fixButtonAlignment: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixButtonAlignment">
		/// Indicate whether the fix button/pin is located to the left or to the right of the header caption.
		/// </summary>
		/// <returns type="$IG.HeaderButtonAlignment">Location of the button.</returns>

		return this._get_clientOnlyValue("cfsba");
	},

	get_showFixButton: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.showFixButton">
		/// Determines if the pin button for fixing the column is shown next to the header caption.
		/// </summary>
		/// <returns type="boolean">True if the button will be displayed, false otherwise </returns>

		return this._get_clientOnlyValue("cfssfb");
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixLocation">
		/// Gets the direction to which the column will be fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column will be fixed to the right edge of the grid
		/// </returns>
		return this._get_value($IG.ColumnFixingSettingProps.FixLocation);
	},

	set_fixLocation: function(value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnFixingSettings.fixLocation">
		/// Sets direction to which the column will be fixed to.
		/// </summary>
		/// <param name="value" type="$IG.FixLocation"  optional="false" mayBeNull="false">
		/// $IG.FixLocation.Left - the column will be fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column will be fixed to the right edge of the grid
		/// </param>
		if (value == $IG.FixLocation.Left || value == $IG.FixLocation.Right)
			return this._set_value($IG.ColumnFixingSettingProps.FixLocation, value);
	}

}
$IG.ColumnFixingSettings.registerClass('Infragistics.Web.UI.ColumnFixingSettings', $IG.ColumnSetting);



$IG.FixedColumnInfo = function(column, fixLocation)
{
	/// <summary locid="T:J#Infragistics.Web.UI.FixedColumnInfo">
	/// Fixed column object.
	/// </summary>
	this._column = column;
	this._fixLocation = fixLocation;
}

$IG.FixedColumnInfo.prototype =
{

	get_column: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FixedColumnInfo.column">
		/// Get the refrence to the grid's column.
		/// </summary>
		/// <returns type="$IG.GridColumn"> Grid's column. </returns>

		return this._column;
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.FixedColumnInfo.fixLocation">
		/// Gets the direction to which the column is fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column is fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column is fixed to the right edge of the grid
		/// </returns>
		return this._fixLocation;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.FixedColumnInfo.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the object will cleanup after itself.
		/// </summary>
		this._column = null;
		this._fixLocation = null;
	}

}
$IG.FixedColumnInfo.registerClass('Infragistics.Web.UI.FixedColumnInfo');



$IG.ClientFixedColumnInfo = function(column, fixLocation)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ClientFixedColumnInfo">
	/// Fixed column object to be used in the FixedStateChanging event.
	/// </summary>
	this._column = column;
	this._fixLocation = fixLocation;
}

$IG.ClientFixedColumnInfo.prototype =
{

	get_column: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientFixedColumnInfo.column">
		/// Get the refrence to the grid's column.
		/// </summary>
		/// <returns type="$IG.GridColumn"> Grid's column. </returns>

		return this._column;
	},

	get_fixLocation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClientFixedColumnInfo.fixLocation">
		/// Gets the direction to which the column is fixed to.
		/// </summary>
		/// <returns type="$IG.FixLocation">
		/// $IG.FixLocation.Left - the column is fixed to the left edge of the grid.
		/// $IG.FixLocation.Right - the column is fixed to the right edge of the grid
		/// </returns>
		return this._fixLocation;
	},

	set_fixLocation: function(direction)
	{
		if (direction == $IG.FixLocation.Left || direction == $IG.FixLocation.Right)
			this._fixLocation = direction;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientFixedColumnInfo.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the object will cleanup after itself.
		/// </summary>
		this._column = null;
		this._fixLocation = null;
	}

}
$IG.ClientFixedColumnInfo.registerClass('Infragistics.Web.UI.ClientFixedColumnInfo');





$IG.FixLocation = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.FixLocation">
	/// Enumeration of values for where a grid's column will be fixed to.
	/// </summary>
}
$IG.FixLocation.prototype =
{
	/// <summary>
	/// Left edge of the grid
	/// </summary>
	Left: 0,

	/// <summary>
	/// Right edge of the grid
	/// </summary>
	Right: 1
};
$IG.FixLocation.registerEnum("Infragistics.Web.UI.FixLocation");



$IG.ColRegion = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.ColRegion">
	/// The region that a column belongs to.
	///</summary>
	/// <field name="LeftFixed" type="Number" integer="true" static="true">Fixed on the left side of the grid.</field>
	/// <field name="Unfixed" type="Number" integer="true" static="true">Not fixed.</field>
	/// <field name="RightFixed" type="Number" integer="true" static="true">Fixed on the right side of the grid.</field>
}
$IG.ColRegion.prototype =
{
	/// <summary>
	/// Fixed on the left side of the grid.
	/// </summary>
	LeftFixed: 0,

	/// <summary>
	/// Not fixed.
	/// </summary>
	Unfixed: 1,

	/// <summary>
	/// Fixed on the right side of the grid.
	/// </summary>
	RightFixed: 2

};
$IG.ColRegion.registerEnum("Infragistics.Web.UI.ColRegion");



$IG.HeaderButtonAlignment = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.HeaderButtonAlignment">
	/// Enumeration of values for where the column fixing button will be placed.
	/// </summary>
}
$IG.HeaderButtonAlignment.prototype =
{
	/// <summary>
	/// Place the button the the left of column header caption
	/// </summary>
	Left: 0,

	/// <summary>
	/// Place the button the the right of column header caption
	/// </summary>
	Right: 1
};
$IG.HeaderButtonAlignment.registerEnum("Infragistics.Web.UI.HeaderButtonAlignment");



$IG.GridColumnFixingProps = new function()
{
	/// <summary>
	/// An enumeration of all the properties that the Column Fixing behavior will send to the client.
	/// </summary>

	this.FixedColumns = [$IG.GridBehaviorProps.Count + 0, null];
	this.FixLocation = [$IG.GridBehaviorProps.Count + 1, $IG.FixLocation.Left];
	this.Count = $IG.GridBehaviorProps.Count + 2;
};


$IG.ColumnFixingSettingProps = new function()
{
	/// <summary>
	/// An enumeration of all the properties that the ColumnFixingSetting object will send to the client.   
	/// </summary> 
	this.FixLocation = [$IG.ColumnSettingProps.Count + 0, $IG.FixLocation.Left];
	this.Count = $IG.ColumnSettingProps.Count + 1;
};




$IG.ColumnFixingAction = function(type, ownerName, object, value, tag)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnFixingAction">
	///Object for event arguments used in the ColumnFixing behaviors to make full or partial postbacks.
	///</summary>

	$IG.ColumnFixingAction.initializeBase(this, [type, ownerName, object, value, tag]);
}
$IG.ColumnFixingAction.prototype =
{
}
$IG.ColumnFixingAction.registerClass('Infragistics.Web.UI.ColumnFixingAction', $IG.GridAction);





$IG.FixingEventArgs = function(behavior, fixedColumn, fixed)
{

	/// <summary locid="T:J#Infragistics.Web.UI.FixingEventArgs">

	/// Class used as EventArgs while raising FixedStateChanging event

	/// </summary>

	$IG.FixingEventArgs.initializeBase(this, [behavior]);


	this._fixed = fixed;

	this._fixedColumn = fixedColumn;
}

$IG.FixingEventArgs.prototype =
{

	get_fixedColumn: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixingEventArgs.fixedColumn">

		/// Get the refrence to the FixedColumnInfo obect whose state is currently changing.

		/// </summary>

		/// <return type="$IG.FixedColumnInfo"> The FixedColumnInfo obect whose state is currently changing </return> 


		return this._fixedColumn;

	},


	get_isFixed: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixingEventArgs.isFixed">

		/// Indicates if the column is currently fixed.

		/// </summary>

		/// <return type="boolean"> True-if the column is currently fixed.  False othersie </return>

		return this._fixed;

	}

}

$IG.FixingEventArgs.registerClass('Infragistics.Web.UI.FixingEventArgs', $IG.CancelBehaviorEventArgs);





$IG.FixedEvenArgs = function(fixedColumn, fixed) //function(fixedColumns)
{

	/// <summary locid="T:J#Infragistics.Web.UI.FixedEvenArgs">

	/// Class used as EventArgs while raising FixedStateChanged event

	/// </summary>


	$IG.FixedEvenArgs.initializeBase(this);

	this._fixed = fixed;

	this._fixedColumn = fixedColumn;

}

$IG.FixedEvenArgs.prototype =
{


	get_fixedColumn: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixedEvenArgs.fixedColumn">

		/// Get the refrence to the FixedColumnInfo obect whose state is currently changing.

		/// </summary>

		/// <return type="$IG.FixedColumnInfo"> The FixedColumnInfo obect whose state is currently changing </return> 


		return this._fixedColumn;

	},


	get_isFixed: function()
	{

		/// <summary locid="P:J#Infragistics.Web.UI.FixedEvenArgs.isFixed">

		/// Indicates if the column is currently fixed.

		/// </summary>

		/// <return type="boolean"> True-if the column is currently fixed.  False otherwise </return>

		return this._fixed;

	}

}

$IG.FixedEvenArgs.registerClass('Infragistics.Web.UI.FixedEvenArgs', $IG.EventArgs);








$IG.FixUnfixColumnEventArgs = function(behavior)
{


	///<summary locid="T:J#Infragistics.Web.UI.FixUnfixColumnEventArgs">

	///Object for event arguments used in the ColumnFixing behavior for Fixing/Unfixing a column.

	///</summary>


	$IG.FixUnfixColumnEventArgs.initializeBase(this, [behavior]);


	

	this._props[1] = (behavior._grid._enableAjax) ? 2 : 1;


}

$IG.FixUnfixColumnEventArgs.prototype =
{
}
$IG.FixUnfixColumnEventArgs.registerClass('Infragistics.Web.UI.FixUnfixColumnEventArgs', $IG.CancelBehaviorEventArgs);

